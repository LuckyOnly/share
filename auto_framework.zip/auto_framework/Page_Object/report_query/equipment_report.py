#coding:utf-8


import time,sys
sys.path.append("D:\\auto_framework\\Page_Object")
from Page_Object.Page_Base import Page_Base
from selenium.webdriver.common.by import By
from selenium.webdriver.support.wait import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import Select

class query(Page_Base):

    def cond_query(self):

        groupName = WebDriverWait(self.driver, timeout=10).until(EC.presence_of_element_located((By.ID, "plazaSel")),
                                                                 message=u'元素加载超时！')
        Select(groupName).select_by_visible_text("长春红旗街万达广场")

        deviceName=WebDriverWait(self.driver,timeout=10).until(EC.presence_of_element_located((By.ID,"DeviceName")),message=u'元素加载超时!')

        deviceName.send_keys("TIANSU0301")
        self.driver.find_element_by_id('btnQuery').click()
        time.sleep(3)




    def check_result(self):
        try:
            Result = self.driver.find_element_by_xpath(".//*[@id='deviceList']/tbody/tr/td[2]")
            # print Result.text
            self.assertNotEquals(Result, u"暂无数据信息", msg="MSG查询有相应数据")
            #print("Result=%s" %Result)
            if (u"暂无数据信息" == Result):
                print ("查询失败，无满足条件的记录")
            else:
                print ("查询成功，有满足条件的记录")

        except:
            print ("查询异常")