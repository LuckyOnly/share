# coding:utf-8

import time, sys

sys.path.append("D:\\auto_framework\\Page_Object")
from Page_Object.Page_Base import Page_Base
from selenium.webdriver.support.wait import WebDriverWait
from selenium.webdriver.support import expected_conditions as ec
from selenium.webdriver.common.by import By


class EquipmentManufacturers(Page_Base):
    def cond_query(self):
        pass_driver = WebDriverWait(self.driver, timeout=10).until(
            ec.presence_of_element_located((By.ID, 'txtKeyword')),
            message=u"元素加载超时！")
        pass_driver.clear()
        pass_driver.send_keys(u"南京天溯")
        self.driver.find_element_by_id('btnQuery').click()

    def cond_query_by_name(self,name):
        time.sleep(3)
        pass_driver = WebDriverWait(self.driver, timeout=10).until(
            ec.presence_of_element_located((By.ID, 'txtKeyword')),
            message=u"元素加载超时！")
        pass_driver.clear()
        pass_driver.send_keys(name)
        self.driver.find_element_by_id('btnQuery').click()

    def reset_query(self):
        pass_driver = WebDriverWait(self.driver, timeout=10).until(
            ec.presence_of_element_located((By.ID, 'txtKeyword')),
            message=u"元素加载超时！")
        pass_driver.clear()
        pass_driver.send_keys(u"南京天溯")
        self.driver.find_element_by_id('btnDefault').click()

    def add_query(self):
        # add_btn = WebDriverWait(self.driver, timeout=10).until(ec.presence_of_element_located((By.XPATH,"html/body/div[3]/div[2]/div[1]/div/span[1]/a"))
        #                     ,message="请求超时！")
        # add_btn.click()
        time.sleep(3)
        self.driver.execute_script("var js = $('#btnInsert').click()")
        time.sleep(5)
        # 型号名称
        name = WebDriverWait(self.driver, timeout=10).until(ec.presence_of_element_located((By.ID, "txtCname")),
                                                            message="请求超时！")
        time.sleep(5)
        name.send_keys("zong-f-f")
        # 型号编码
        type_code = WebDriverWait(self.driver, timeout=10).until(ec.presence_of_element_located((By.ID, "txtTypeCode")),
                                                                 message="请求超时！")
        time.sleep(3)
        type_code.clear()
        type_code.send_keys("100")

        # 联系人
        type_code = WebDriverWait(self.driver, timeout=10).until(ec.presence_of_element_located((By.ID, "txtContact")),
                                                                 message="请求超时！")
        time.sleep(3)
        type_code.clear()
        type_code.send_keys("zong-f-f")

        # 联系电话
        type_code = WebDriverWait(self.driver, timeout=10).until(ec.presence_of_element_located((By.ID, "txtContactNumber")),
                                                                 message="请求超时！")
        type_code.clear()
        type_code.send_keys("12345678998")

        # 厂家地址
        type_code = WebDriverWait(self.driver, timeout=10).until(ec.presence_of_element_located((By.ID, "txtAddress")),
                                                                 message="请求超时！")
        time.sleep(3)
        type_code.clear()
        type_code.send_keys("test")
        time.sleep(3)
        self.driver.find_element_by_id('btnOk').click()
        time.sleep(3)

    def modify_query(self,name, name_a, name_b):
        self.cond_query_by_name(name_a)
        # 定位修改按钮
        WebDriverWait(self.driver, timeout=10).until(
            ec.presence_of_element_located((By.XPATH, "html/body/div[3]/div[2]/div[2]/table/tbody/tr/td[10]/a[1]")),
            message="请求超时！").click()
        time.sleep(3)

        if u"联系电话" == name.decode('utf-8'):
            # 联系电话
            modify_name = WebDriverWait(self.driver, timeout=10).until(
                ec.presence_of_element_located((By.ID, "txtContactNumber")),
                message="请求超时！")
        if u"联系人" == name.decode('utf-8'):
            # 联系人
            modify_name = WebDriverWait(self.driver, timeout=10).until(
                ec.presence_of_element_located((By.ID, "txtContact")),
                message="请求超时！")
        if u"厂家地址" == name.decode('utf-8'):
            # 联系人
            modify_name = WebDriverWait(self.driver, timeout=10).until(
                ec.presence_of_element_located((By.ID, "txtAddress")),
                message="请求超时！")
        modify_name.clear()
        modify_name.send_keys(name_b)
        time.sleep(3)
        self.driver.find_element_by_id('btnOk').click()
        time.sleep(3)

    def delete_name(self,name):
        self.cond_query_by_name(name)
        time.sleep(5)
        find_name = self.driver.find_element_by_xpath('html/body/div[3]/div[2]/div[2]/table/tbody/tr/td[3]').text
        assert str(name).decode('utf-8') in find_name

        del_btn = WebDriverWait(self.driver,timeout=10).until(ec.presence_of_element_located((By.XPATH, "html/body/div[3]/div[2]/div[2]/table/tbody/tr/td[10]/a[2]"))
                                                              ,message="请求超时！")
        del_btn.click()
        time.sleep(3)
        self.driver.switch_to_alert().accept()
        time.sleep(3)

    def check_delete_result(self):
        name =100
        self.cond_query_by_name(name)
        result = WebDriverWait(self.driver,timeout=10).until(ec.presence_of_element_located((By.XPATH, "html/body/div[3]/div[2]/div[2]/table/tbody/tr/td"))
                                                              ,message="请求超时！")
        if result.text == u"暂无数据信息":
            print ("删除成功")
        else:
            print ("删除失败")

    def check_result(self):
        try:
            result = self.driver.find_element_by_xpath("//*[@id='factory_lst']/tr/td").text
            self.assertNotEquals(result, u"暂无数据信息", msg="MSG查询有相应数据")
            if u"暂无数据信息" == result:
                print ("查询失败，无满足条件的记录")
            else:
                print ("查询成功，有满足条件的记录")
        except Exception as e:
            print ("查询异常", e.message)

    def check_reset_result(self):
        try:
            result = WebDriverWait(self.driver, timeout=10).until(
            ec.presence_of_element_located((By.ID, 'txtKeyword')),
            message=u"元素加载超时！")
            if u"" == result.get_attribute('value'):
                print ("查询失败，无满足条件的记录")
            else:
                print ("查询成功，有满足条件的记录")
        except Exception as e:
            print ("查询异常", e.message)

    def check_result_by_name(self,name, name_a, name_b):
        try:
            if u"联系电话" == name.decode('utf-8'):
                # 联系电话
                modify_name = WebDriverWait(self.driver, timeout=10).until(
                    ec.presence_of_element_located((By.XPATH, "html/body/div[3]/div[2]/div[2]/table/tbody/tr/td[6]")),
                    message="请求超时！")
            if u"联系人" == name.decode('utf-8'):
                # 联系人
                modify_name = WebDriverWait(self.driver, timeout=10).until(
                    ec.presence_of_element_located((By.XPATH, "html/body/div[3]/div[2]/div[2]/table/tbody/tr/td[5]")),
                    message="请求超时！")
            if u"厂家地址" == name.decode('utf-8'):
                # 联系人
                modify_name = WebDriverWait(self.driver, timeout=10).until(
                    ec.presence_of_element_located((By.XPATH, "html/body/div[3]/div[2]/div[2]/table/tbody/tr/td[7]")),
                    message="请求超时！")
            time.sleep(3)
            if modify_name.text == name_b.decode('utf-8'):
                print ('校验通过')
            else:
                print ('校验失败')
        except Exception as e:
            print ('查询异常', e.message)