# coding:utf-8

import sys
import time
from selenium.webdriver.support.select import Select
from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as ec
from selenium.webdriver.support.wait import WebDriverWait

from Page_Object.Page_Base import Page_Base

reload(sys)
sys.setdefaultencoding('utf8')  # 修改系统的默认编码


class UploadFile(Page_Base):

    def cond_query(self):
        group_name = WebDriverWait(self.driver,timeout= 10).until(ec.presence_of_element_located((By.ID,"sltPlaza")),
                                         message="请求超时！")
        time.sleep(3)
        Select(group_name).select_by_visible_text("长沙开福万达广场")
        # group_name = WebDriverWait(self.driver,timeout= 10).until(ec.presence_of_element_located((By.ID,"sltPlaza")),
        #                                  message="请求超时！")
        #
        # option_name = group_name.find_elements_by_tag_name('option')
        # print option_name
        # Select(group_name).select_by_visible_text(group)

        btn = WebDriverWait(self.driver,timeout=10).until(ec.presence_of_element_located((By.ID, "btnQuery")),
                                                    message="请求超时")
        btn.click()

    def check_result(self):
        try:
            result = WebDriverWait(self.driver,timeout=10).until(ec.presence_of_element_located((By.XPATH, "html/body/div[1]/div[3]/div/div/div[2]/div/div/div[2]/table/tbody/tr[1]/td[3]")),
                                message="请求超时")

            self.assertNotEquals(result.text, u"暂无数据信息", msg="MSG查询有相应数据")
            if result.text == u"2018.xlsx":
                print ("查询成功")
            else:
                print("查询失败")

        except Exception as e:
            print ("查询异常",e.message)

    def check_result_by_group(self,name):
        try:
            table_lst = WebDriverWait(self.driver,timeout=10).until(ec.presence_of_element_located((By.ID, "tbl_lst")),
                                message="请求超时")

            td_lst = table_lst.find_elements_by_tag_name('tr')[0].find_elements_by_tag_name('td')[1]
            self.assertNotEquals(td_lst.text, u"暂无数据信息", msg="MSG查询有相应数据")

            if td_lst.text == name.decode('utf-8'):
                print ("查询成功")
            else:
                print("查询失败")

        except Exception as e:
            print ("查询异常",e.message)

    def add_file_by_name(self,name):
        print name
        group_name = WebDriverWait(self.driver,timeout= 10).until(ec.presence_of_element_located((By.ID,"sltPlaza")),
                                         message="请求超时！")
        time.sleep(3)
        Select(group_name).select_by_visible_text("长沙开福万达广场")
        # ops = group_name.find_elements_by_tag_name('option')[3]
        # print ops.text
        # ops.click()
        time.sleep(3)
        file_btn = WebDriverWait(self.driver,timeout=10).until(ec.presence_of_element_located((By.ID,"UpImagePath")),
                                       message="请求超时！")

        file_btn.send_keys(name)
        time.sleep(3)
        upload_btn = WebDriverWait(self.driver,timeout=10).until(ec.presence_of_element_located((By.ID, "BtnUpload")),
                                                    message="请求超时")
        print upload_btn
        upload_btn.click()

        alert_btn = self.driver.switch_to_alert()
        alert_btn.accept()
        time.sleep(5)

    def delete_file(self):
        self.cond_query()
        try:
            table_lst = WebDriverWait(self.driver,timeout=10).until(ec.presence_of_element_located((By.ID, "tbl_lst")),
                                message="请求超时")
            tr_lst = table_lst.find_elements_by_tag_name('tr')[0]
            if tr_lst.find_elements_by_tag_name('td')[0].text == u"暂无数据信息":
                print ("没有数据需要删除")
            else:
                WebDriverWait(self.driver, timeout=10).until(ec.presence_of_element_located((By.XPATH, "html/body/div[1]/div[3]/div/div/div[2]/div/div/div[2]/table/tbody/tr/td[6]/span/span")),
                                                             message="请求超时").click()

                alert_btn = self.driver.switch_to_alert()
                alert_btn.accept()

        except Exception as e:
            print ("查询异常",e.message)

    def check_delete_file(self):
        self.cond_query()
        try:
            table_lst = WebDriverWait(self.driver,timeout=10).until(ec.presence_of_element_located((By.ID, "tbl_lst")),
                                message="请求超时")
            tr_lst = table_lst.find_elements_by_tag_name('tr')[0]
            if tr_lst.find_elements_by_tag_name('td')[0].text == u"暂无数据信息":
                print ("删除成功")
            else:
                print ("删除失败")
        except Exception as e:
            print ("查询异常",e.message)