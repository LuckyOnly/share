# coding:utf-8

import sys
import time
from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as ec
from selenium.webdriver.support.wait import WebDriverWait

from Page_Object.Page_Base import Page_Base

reload(sys)
sys.setdefaultencoding('utf8')  # 修改系统的默认编码


class ConcentratorModel(Page_Base):
    def reset_cond(self):
        # 规范类型
        station_type = WebDriverWait(self.driver, timeout=10).until(
            ec.presence_of_element_located((By.ID, "sltStationType")),
            message=u'元素加载超时！')
        station_type.find_elements_by_tag_name("option")[1].click()
        time.sleep(3)
        # 设备厂家
        factory = WebDriverWait(self.driver, timeout=10).until(ec.presence_of_element_located((By.ID, "sltFactorys")),
                                                               message=u'元素加载超时！')
        factory.find_elements_by_tag_name("option")[1].click()
        time.sleep(3)
        pass_driver = WebDriverWait(self.driver, timeout=10).until(ec.presence_of_element_located((By.ID, 'Address')),
                                                                   message=u"元素加载超时！")
        pass_driver.send_keys("NTS-165")
        self.driver.find_element_by_id('reSet').click()
        time.sleep(3)

    def cond_query(self):
        # self.driver.find_element_by_id("sltStationType").find_elements_by_tag_name("option")[2].click()
        # self.driver.find_element_by_id("sltFactorys").find_elements_by_tag_name("option")[1].click()
        station_type = WebDriverWait(self.driver, timeout=10).until(
            ec.presence_of_element_located((By.ID, 'sltStationType')), message=u"元素加载超时！")
        station_type.find_elements_by_tag_name("option")[2].click()

        factory = WebDriverWait(self.driver, timeout=10).until(ec.presence_of_element_located((By.ID, 'sltFactorys')),
                                                               message=u"元素加载超时！")
        factory.find_elements_by_tag_name("option")[1].click()
        pass_driver = WebDriverWait(self.driver, timeout=10).until(ec.presence_of_element_located((By.ID, 'Address')),
                                                                   message=u"元素加载超时！")
        pass_driver.send_keys("NTS-165")
        self.driver.find_element_by_id('search-btn').click()

    def cond_query_by_name(self, name):
        time.sleep(3)
        pass_driver = WebDriverWait(self.driver, timeout=10).until(ec.presence_of_element_located((By.ID, 'Address')),
                                                                   message=u"元素加载超时！")
        pass_driver.clear()
        pass_driver.send_keys(name)
        self.driver.find_element_by_id('search-btn').click()

        time.sleep(5)

    def delete_by_code_name(self, name):
        try:
            self.cond_query_by_name(name)
            find_name = self.driver.find_element_by_xpath('html/body/div[1]/div[3]/div/div[2]/div[2]/table/tbody/tr[1]/td[3]').text
            assert str(name).decode('utf-8') in find_name
            time.sleep(3)
            # 选中添加的标签
            # btn_add = WebDriverWait(self.driver, timeout=10).until(ec.presence_of_element_located(
            #     (By.XPATH, 'html/body/div[1]/div[3]/div/div[2]/div[2]/table/tbody/tr[1]/td[10]/span[2]')),
            #                                                        message=u"删除的对象不存在或者加载超时！")
            # self.add_concentrator(name)
            # self.cond_query_by_name(name)
            # time.sleep(3)
            btn_add = WebDriverWait(self.driver, timeout=10).until(ec.presence_of_element_located(
                (By.XPATH, 'html/body/div[1]/div[3]/div/div[2]/div[2]/table/tbody/tr[1]/td[10]/span[2]')),
                message=u"删除的对象不存在或者加载超时！")
            btn_add.click()
            time.sleep(3)
            self.driver.switch_to_alert().accept()
            time.sleep(2)
            alert_bnt = self.driver.switch_to_alert()
            alert_bnt.accept()
            time.sleep(2)
        except Exception as e:
            print ("删除对象不存在,不需要删除", e.message)

    def reset_add_concentrator(self):
        btn_add = WebDriverWait(self.driver, timeout=10).until(
            ec.presence_of_element_located((By.XPATH, 'html/body/div[1]/div[3]/div/div[2]/div[1]/span[3]/a')),
            message=u"元素加载超时！")
        btn_add.click()
        time.sleep(5)
        code_name = WebDriverWait(self.driver, timeout=10).until(ec.presence_of_element_located((By.ID, 'txtTypeCode')),
                                                                 message=u'元素加载超时！')
        code_name.send_keys('zongff')
        time.sleep(3)
        station_name = WebDriverWait(self.driver, timeout=10).until(
            ec.presence_of_element_located((By.ID, 'txtStationName')), message=u'元素加载超时！')
        station_name.click()
        time.sleep(3)
        station_name.send_keys('zongff')
        time.sleep(3)
        normal_type = WebDriverWait(self.driver, timeout=10).until(
            ec.presence_of_element_located((By.ID, 'sltStationTypeDialog')),
            message=u'元素加载超时！')
        normal_type.find_elements_by_tag_name('option')[0].click()
        time.sleep(3)
        count = WebDriverWait(self.driver, timeout=10).until(ec.presence_of_element_located((By.ID, 'txtPathCount')),
                                                             message=u'元素加载超时！')
        count.send_keys('1')
        time.sleep(3)
        type_factory = WebDriverWait(self.driver, timeout=10).until(
            ec.presence_of_element_located((By.ID, 'sltFactorysDialog')),
            message=u'元素加载超时！')
        type_factory.find_elements_by_tag_name('option')[1].click()
        self.driver.find_element_by_xpath('html/body/div[3]/div[3]/div/button[2]').click()
        time.sleep(2)

    def reset_modify_concentrator(self, name):
        # 查询需要修改的name
        self.cond_query_by_name(name)
        # 获取修改按钮
        btn_modify = WebDriverWait(self.driver, timeout=10).until(ec.presence_of_element_located(
            (By.XPATH, 'html/body/div[1]/div[3]/div/div[2]/div[2]/table/tbody/tr/td[10]/span[1]')),
                                                                  message=u"元素加载超时！")
        btn_modify.click()
        time.sleep(5)
        code_name = WebDriverWait(self.driver, timeout=10).until(ec.presence_of_element_located((By.ID, 'txtTypeCode')),
                                                                 message=u'元素加载超时！')
        code_name.send_keys('zongff')
        time.sleep(3)
        station_name = WebDriverWait(self.driver, timeout=10).until(
            ec.presence_of_element_located((By.ID, 'txtStationName')), message=u'元素加载超时！')
        station_name.click()
        time.sleep(3)
        station_name.send_keys('zongff')
        time.sleep(3)
        normal_type = WebDriverWait(self.driver, timeout=10).until(
            ec.presence_of_element_located((By.ID, 'sltStationTypeDialog')),
            message=u'元素加载超时！')
        normal_type.find_elements_by_tag_name('option')[1].click()
        time.sleep(3)
        count = WebDriverWait(self.driver, timeout=10).until(ec.presence_of_element_located((By.ID, 'txtPathCount')),
                                                             message=u'元素加载超时！')
        count.send_keys('2')
        time.sleep(3)
        type_factory = WebDriverWait(self.driver, timeout=10).until(
            ec.presence_of_element_located((By.ID, 'sltFactorysDialog')),
            message=u'元素加载超时！')
        type_factory.find_elements_by_tag_name('option')[4].click()
        self.driver.find_element_by_xpath('html/body/div[3]/div[3]/div/button[2]').click()
        time.sleep(2)

    def add_concentrator(self, name):
        # 选中添加的标签
        btn_add = WebDriverWait(self.driver, timeout=10).until(
            ec.presence_of_element_located((By.XPATH, 'html/body/div[1]/div[3]/div/div[2]/div[1]/span[3]/a')),
            message=u"元素加载超时！")
        # btn_add.clear()
        btn_add.click()
        time.sleep(5)
        code_name = WebDriverWait(self.driver, timeout=10).until(ec.presence_of_element_located((By.ID, 'txtTypeCode')),
                                                                 message=u'元素加载超时！')
        code_name.clear()
        code_name.send_keys(name)
        time.sleep(3)
        station_name = WebDriverWait(self.driver, timeout=10).until(
            ec.presence_of_element_located((By.ID, 'txtStationName')), message=u'元素加载超时！')
        station_name.clear()
        time.sleep(3)
        # station_name.click()
        station_name.send_keys(name)
        time.sleep(3)
        normal_type = WebDriverWait(self.driver, timeout=10).until(
            ec.presence_of_element_located((By.ID, 'sltStationTypeDialog')),
            message=u'元素加载超时！')
        normal_type.find_elements_by_tag_name('option')[0].click()
        time.sleep(3)
        count = WebDriverWait(self.driver, timeout=10).until(ec.presence_of_element_located((By.ID, 'txtPathCount')),
                                                             message=u'元素加载超时！')
        count.clear()
        count.send_keys('1')
        time.sleep(3)
        type_factory = WebDriverWait(self.driver, timeout=10).until(
            ec.presence_of_element_located((By.ID, 'sltFactorysDialog')),
            message=u'元素加载超时！')
        type_factory.find_elements_by_tag_name('option')[1].click()

        self.driver.find_element_by_xpath('html/body/div[3]/div[3]/div/button[1]').click()

        time.sleep(5)

        alert_bnt = self.driver.switch_to_alert()

        try:
            if alert_bnt.text == u"新增成功":
                print ("新增成功")
            else:
                print ("新增失败，" + name + "已存在此厂家下,请检查")
        except Exception as e:
            print ("查询异常", e)
        alert_bnt.accept()

    def modify_code_name(self, modify_name, name_a, name_b):
        # modify_name 修改的对象 name_a 是修改前的型号编码  name_b 是修改后的型号编码，或者型号名称，或通道号 或规范类型
        self.cond_query_by_name(name_a)
        """ 获取修改的按钮"""
        modify_btn = WebDriverWait(self.driver, timeout=10).until(ec.presence_of_element_located(
            (By.XPATH, 'html/body/div[1]/div[3]/div/div[2]/div[2]/table/tbody/tr/td[10]/span[1]')), message=u"超时操作")
        modify_btn.click()
        time.sleep(3)
        """修改对象"""
        if modify_name == '型号编码':
            code_name = WebDriverWait(self.driver, timeout=10).until(
                ec.presence_of_element_located((By.ID, 'txtTypeCode')),
                message=u'元素加载超时！')
            code_name.clear()
            code_name.send_keys(name_b)
            time.sleep(3)
            station_name = WebDriverWait(self.driver, timeout=10).until(
                ec.presence_of_element_located((By.ID, 'txtStationName')), message=u'元素加载超时！')
            station_name.clear()
            station_name.click()
            station_name.send_keys(name_b)
            time.sleep(3)
        if modify_name == '通道数':
            count = WebDriverWait(self.driver, timeout=10).until(
                ec.presence_of_element_located((By.ID, 'txtPathCount')), message=u'元素加载超时！')
            count.clear()
            count.send_keys(name_b)
            time.sleep(3)

        if modify_name == '规范类型':
            normal_type = WebDriverWait(self.driver, timeout=10).until(
                ec.presence_of_element_located((By.ID, 'sltStationTypeDialog')),
                message=u'元素加载超时！')
            option_types = normal_type.find_elements_by_tag_name('option')
            for types in option_types:
                if types.text == name_b.decode('utf-8'):
                    types.click()
                    break
            time.sleep(3)
        if modify_name == '设备厂家':
            type_factory = WebDriverWait(self.driver, timeout=10).until(
                ec.presence_of_element_located((By.ID, 'sltFactorysDialog')),
                message=u'元素加载超时！')
            option_types = type_factory.find_elements_by_tag_name('option')
            for types in option_types:
                if types.text == name_b.decode('utf-8'):
                    types.click()
                    print types.text
                    break
            time.sleep(3)
        self.driver.find_element_by_xpath('html/body/div[3]/div[3]/div/button[1]').click()

        time.sleep(5)

        alert_bnt = self.driver.switch_to_alert()

        try:
            if alert_bnt.text == u"修改成功":
                print (u"修改成功")
            else:
                print (modify_name, u"修改失败")
        except Exception as e:
            print (u"查询异常", e)
        alert_bnt.accept()

    def check_result(self):
        try:
            result = self.driver.find_element_by_xpath("//*[@id='dataList']/tr/td").text
            self.assertNotEquals(result, u"暂无数据信息", msg="MSG查询有相应数据")
            if u"暂无数据信息" == result:
                print (u"查询失败，无满足条件的记录")
            else:
                print (u"查询成功，有满足条件的记录")

        except Exception as e:
            print (u"查询异常", e)

    def check_result_by_name(self, name):
        self.cond_query_by_name(name)
        try:
            result = self.driver.find_element_by_xpath(
                "html/body/div[1]/div[3]/div/div[2]/div[2]/table/tbody/tr[1]/td[3]").text
            self.assertNotEquals(result, u"暂无数据信息", msg="MSG查询有相应数据")
            if u"暂无数据信息" == result:
                print (u"查询失败，无满足条件的记录")
            else:
                print (u"查询成功，有满足条件的记录")

        except Exception as e:
            print (u"查询异常", e)

    def check_result_by_delete_name(self, name):
        self.cond_query_by_name(name)
        try:
            result = self.driver.find_element_by_xpath(
                "html/body/div[1]/div[3]/div/div[2]/div[2]/table/tbody/tr/td").text
            if u"暂无数据信息" == result:
                print (u"删除成功")
            else:
                print (u"删除失败")

        except Exception as e:
            print (u"删除异常", e)

    def check_result_by_type(self, modify_name, name_a, name_b):
        # modify_name 是修改对象 name_a 是修改对应的型号编码 name_b 修改后的值
        self.cond_query_by_name(name_a)
        try:
            result = self.driver.find_element_by_xpath(
                "html/body/div[1]/div[3]/div/div[2]/div[2]/table/tbody/tr[1]/td[3]").text
            self.assertNotEquals(result, u"暂无数据信息", msg="MSG查询有相应数据")
            if u"暂无数据信息" == result:
                print (u"查询失败，无满足条件的记录")
            else:
                count = ""
                if modify_name == "通道数":
                    count = self.driver.find_element_by_xpath(
                        "html/body/div[1]/div[3]/div/div[2]/div[2]/table/tbody/tr[1]/td[6]").text
                if modify_name == "规范类型":
                    count = self.driver.find_element_by_xpath(
                        "html/body/div[1]/div[3]/div/div[2]/div[2]/table/tbody/tr[1]/td[5]").text
                if modify_name == "设备厂家":
                    count = self.driver.find_element_by_xpath(
                        "html/body/div[1]/div[3]/div/div[2]/div[2]/table/tbody/tr[1]/td[7]").text
                    print count
                assert count in name_b.decode('utf-8')
                print (u"查询成功，有满足条件的记录")

        except Exception as e:
            print (u"查询异常", e)

    def check_cond(self):
        try:
            # 规范类型
            station_type = WebDriverWait(self.driver, timeout=10).until(
                ec.presence_of_element_located((By.ID, "sltStationType")),
                message=u'元素加载超时！')

            assert u"全部" in station_type.text
            time.sleep(3)
            # 设备厂家
            factory = WebDriverWait(self.driver, timeout=10).until(
                ec.presence_of_element_located((By.ID, "sltFactorys")),
                message=u'元素加载超时！')

            assert u"全部" in factory.text
            time.sleep(3)
            pass_driver = WebDriverWait(self.driver, timeout=10).until(
                ec.presence_of_element_located((By.ID, 'Address')),
                message=u"元素加载超时！")

            assert u"" in pass_driver.get_attribute('value')
        except Exception as e:
            print (u"查询异常", e)

    def check_reset(self):
        try:
            # btn_add = WebDriverWait(self.driver, timeout=10).until(
            #     ec.presence_of_element_located((By.XPATH, 'html/body/div[1]/div[3]/div/div[2]/div[1]/span[3]/a')),
            #     message=u"元素加载超时！")
            # btn_add.click()
            time.sleep(5)
            code_name = WebDriverWait(self.driver, timeout=10).until(
                ec.presence_of_element_located((By.ID, 'txtTypeCode')), message=u'元素加载超时！')
            assert "" in code_name.text
            time.sleep(3)
            station_name = WebDriverWait(self.driver, timeout=10).until(
                ec.presence_of_element_located((By.ID, 'txtStationName')), message=u'元素加载超时！')
            station_name.click()
            assert "" in station_name.text
            time.sleep(3)
            normal_type = WebDriverWait(self.driver, timeout=10).until(
                ec.presence_of_element_located((By.ID, 'sltStationTypeDialog')),
                message=u'元素加载超时！')
            assert u"国网" in normal_type.text
            time.sleep(3)
            count = WebDriverWait(self.driver, timeout=10).until(
                ec.presence_of_element_located((By.ID, 'txtPathCount')), message=u'元素加载超时！')
            assert "" in count.text
            time.sleep(3)
            type_factory = WebDriverWait(self.driver, timeout=10).until(
                ec.presence_of_element_located((By.ID, 'sltFactorysDialog')),
                message=u'元素加载超时！')
            assert "" in type_factory.text
        except Exception as e:
            print ('查询异常', e)

    def check_reset_modify(self, name):
        # try:
        # except Exception as e:
        #     print ('查询异常', e)
        btn_add = WebDriverWait(self.driver, timeout=10).until(ec.presence_of_element_located((By.XPATH, 'html/body'
                                                                                                         '/div['
                                                                                                         '1]/div['
                                                                                                         '3]/div/div['
                                                                                                         '2]/div['
                                                                                                         '1]/span['
                                                                                                         '3]/a')),
                                                               message=u"元素加载超时！")
        btn_add.click()
        time.sleep(5)
        code_name = WebDriverWait(self.driver, timeout=10).until(ec.presence_of_element_located((By.ID, 'txtTypeCode')),
                                                                 message=u'元素加载超时！')
        assert code_name.text in name.decode('utf-8')
        time.sleep(3)
        station_name = WebDriverWait(self.driver, timeout=10).until(
            ec.presence_of_element_located((By.ID, 'txtStationName')), message=u'元素加载超时！')
        station_name.click()
        assert station_name.text in name.decode('utf-8')
        time.sleep(3)
        normal_type = WebDriverWait(self.driver, timeout=10).until(
            ec.presence_of_element_located((By.ID, 'sltStationTypeDialog')),
            message=u'元素加载超时！')
        chosen_type = normal_type.find_elements_by_tag_name('option')[0]
        assert chosen_type.text in u"国网"
        time.sleep(3)
        count = WebDriverWait(self.driver, timeout=10).until(ec.presence_of_element_located((By.ID, 'txtPathCount')),
                                                             message=u'元素加载超时！')
        assert count.text in u"1"
        time.sleep(3)
        type_factory = WebDriverWait(self.driver, timeout=10).until(
            ec.presence_of_element_located((By.ID, 'sltFactorysDialog')),
            message=u'元素加载超时！')
        chosen_factory = type_factory.find_elements_by_tag_name('option')[1]
        assert chosen_factory.text in u"深圳科陆"
