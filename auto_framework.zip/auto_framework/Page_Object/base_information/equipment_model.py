# coding: utf-8

from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as ec
from selenium.webdriver.support.wait import WebDriverWait
from Page_Object.Page_Base import Page_Base
import time


class EquipmentModel(Page_Base):
    def cond_modify_by_name(self, name_a, name, name_b):
        self.cond_query_by_name(name)
        # 定位修改按钮
        WebDriverWait(self.driver, timeout=10).until(
            ec.presence_of_element_located((By.XPATH, "html/body/div[3]/div[2]/div[2]/table/tbody/tr/td[15]/a[1]")),
            message="请求超时！").click()
        time.sleep(3)
        # 型号名称
        if name_a == '型号名称':
            name = WebDriverWait(self.driver, timeout=10).until(ec.presence_of_element_located((By.ID, "txtCname")),
                                                                message="请求超时！")
            name.click()
            name.clear()
            name.send_keys(name_b)
        # 型号编码
        if name_a == '型号编码':
            type_code = WebDriverWait(self.driver, timeout=10).until(
                ec.presence_of_element_located((By.ID, "txtTypeCode")),
                message="请求超时！")
            type_code.click()
            type_code.clear()
            type_code.send_keys(name_b)
        # 电表类型
        if name_a == '电表类型':
            dev_second = WebDriverWait(self.driver, timeout=10).until(
                ec.presence_of_element_located((By.ID, "selDevSecond")),
                message="请求超时！")
            option_types = dev_second.find_elements_by_tag_name('option')
            for types in option_types:
                if types.text == name_b.decode('utf-8'):
                    types.click()
                    break
        # 测量类型
        if name_a == '测量类型':
            sel_phase = WebDriverWait(self.driver, timeout=10).until(
                ec.presence_of_element_located((By.ID, "selPhase")),
                message="请求超时！")
            option_types = sel_phase.find_elements_by_tag_name('option')
            for types in option_types:
                if types.text == name_b.decode('utf-8'):
                    types.click()
                    break
        # 合闸方式
        if name_a == '合闸方式':
            sel_switch = WebDriverWait(self.driver, timeout=10).until(
                ec.presence_of_element_located((By.ID, "selSwitchType")),
                message="请求超时！")
            option_types = sel_switch.find_elements_by_tag_name('option')
            for types in option_types:
                if types.text == name_b.decode('utf-8'):
                    types.click()
                    break
        # 规范类型
        if name_a == '规范类型':
            sel_dev = WebDriverWait(self.driver, timeout=10).until(ec.presence_of_element_located((By.ID, "selDevType")),
                                                                   message="请求超时！")
            option_types = sel_dev.find_elements_by_tag_name('option')
            for types in option_types:
                if types.text == name_b.decode('utf-8'):
                    types.click()
                    break

        # 最大电流规格
        if name_a == '最大电流规格':
            text_limit = WebDriverWait(self.driver, timeout=10).until(ec.presence_of_element_located((By.ID, "txtALimit")),
                                                                      message="请求超时！")
            text_limit.click()
            text_limit.clear()
            text_limit.send_keys(name_b)
        # 最大充值金额
        if name_a == '最大充值金额':
            dev_limit = WebDriverWait(self.driver, timeout=10).until(ec.presence_of_element_located((By.ID, "txtDevLimit")),
                                                                     message="请求超时！")
            dev_limit.click()
            dev_limit.clear()
            dev_limit.send_keys(name_b)
        # 单次最大充值金额
        if name_a == '单次最大充值金额':
            dev_limit = WebDriverWait(self.driver, timeout=10).until(
                ec.presence_of_element_located((By.ID, "txtOneDevLimit")),
                message="请求超时！")
            dev_limit.click()
            dev_limit.clear()
            dev_limit.send_keys(name_b)
        # 设备厂家名称
        if name_a == '设备厂家名称':
            sel_factory = WebDriverWait(self.driver, timeout=10).until(
                ec.presence_of_element_located((By.ID, "selFactory")),
                message="请求超时！")
            option_types = sel_factory.find_elements_by_tag_name('option')
            for types in option_types:
                if types.text == name_b.decode('utf-8'):
                    types.click()
                    break
        time.sleep(5)
        self.driver.find_element_by_id('btnOk').click()
        time.sleep(4)

    def cond_query(self):
        model_code = WebDriverWait(self.driver, timeout=10).until(ec.presence_of_element_located((By.ID, 'txtKeyword')),
                                                                  message=u"元素加载超时！")
        model_code.send_keys("")
        self.driver.find_element_by_id("queryPhase").find_elements_by_tag_name("option")[2].click()
        self.driver.find_element_by_id("queryDevSecond").find_elements_by_tag_name("option")[2].click()
        self.driver.find_element_by_id("queryDevType").find_elements_by_tag_name("option")[2].click()
        self.driver.find_element_by_id("queryFactory").find_elements_by_tag_name("option")[1].click()
        self.driver.find_element_by_id('btnQuery').click()

    def cond_add(self, c_name):
        # 获取添加按钮
        time.sleep(2)
        # WebDriverWait(self.driver, timeout=10).until(ec.presence_of_element_located((By.ID, "btnInsert")),
        #                                              message="请求超时！").click()
        self.driver.execute_script("var js = $('#btnInsert').click()")
        time.sleep(3)
        # 型号名称
        name = WebDriverWait(self.driver, timeout=10).until(ec.presence_of_element_located((By.ID, "txtCname")),
                                                            message="请求超时！")
         # self.driver.execute_script("var js = $('#txtCname') ")
        # name.click()
        name.clear()
        name.send_keys(c_name)
        # 型号编码
        type_code = WebDriverWait(self.driver, timeout=10).until(ec.presence_of_element_located((By.ID, "txtTypeCode")),
                                                                 message="请求超时！")
        type_code.clear()
        type_code.send_keys(c_name)
        # 电表类型
        dev_second = WebDriverWait(self.driver, timeout=10).until(
            ec.presence_of_element_located((By.ID, "selDevSecond")),
            message="请求超时！")
        dev_second.find_elements_by_tag_name('option')[1].click()
        # 测量类型
        sel_phase = WebDriverWait(self.driver, timeout=10).until(ec.presence_of_element_located((By.ID, "selPhase")),
                                                                 message="请求超时！")
        sel_phase.find_elements_by_tag_name('option')[1].click()
        # 合闸方式
        sel_switch = WebDriverWait(self.driver, timeout=10).until(
            ec.presence_of_element_located((By.ID, "selSwitchType")),
            message="请求超时！")
        sel_switch.find_elements_by_tag_name('option')[1].click()
        # 规范类型
        sel_dev = WebDriverWait(self.driver, timeout=10).until(ec.presence_of_element_located((By.ID, "selDevType")),
                                                               message="请求超时！")
        sel_dev.find_elements_by_tag_name('option')[1].click()
        # 最大电流规格
        text_limit = WebDriverWait(self.driver, timeout=10).until(ec.presence_of_element_located((By.ID, "txtALimit")),
                                                                  message="请求超时！")
        text_limit.send_keys('3000')
        # 最大充值金额
        dev_limit = WebDriverWait(self.driver, timeout=10).until(ec.presence_of_element_located((By.ID, "txtDevLimit")),
                                                                 message="请求超时！")
        dev_limit.clear()
        dev_limit.send_keys('1000')
        # 单次最大充值金额
        dev_limit = WebDriverWait(self.driver, timeout=10).until(
            ec.presence_of_element_located((By.ID, "txtOneDevLimit")),
            message="请求超时！")
        dev_limit.clear()
        dev_limit.send_keys('10')
        sel_factory = WebDriverWait(self.driver, timeout=10).until(
            ec.presence_of_element_located((By.ID, "selFactory")),
            message="请求超时！")
        sel_factory.find_elements_by_tag_name('option')[1].click()
        self.driver.find_element_by_id('btnOk').click()
        time.sleep(13)

    def cond_query_by_name(self, name):
        model_code = WebDriverWait(self.driver, timeout=10).until(ec.presence_of_element_located((By.ID, 'txtKeyword')),
                                                                  message=u"元素加载超时！")
        model_code.clear()
        model_code.send_keys(name)
        self.driver.find_element_by_id('btnQuery').click()
        time.sleep(2)

    def cond_reset(self, name):
        model_code = WebDriverWait(self.driver, timeout=10).until(ec.presence_of_element_located((By.ID, 'txtKeyword')),
                                                                  message=u"元素加载超时！")
        model_code.send_keys(name)
        self.driver.find_element_by_id("queryPhase").find_elements_by_tag_name("option")[1].click()
        self.driver.find_element_by_id("queryDevSecond").find_elements_by_tag_name("option")[2].click()
        self.driver.find_element_by_id("queryDevType").find_elements_by_tag_name("option")[1].click()
        self.driver.find_element_by_id("queryFactory").find_elements_by_tag_name("option")[2].click()
        self.driver.find_element_by_id('btnDefault').click()

    def cond_reset_by_name(self,modify_name,name_a,name_b):
        self.cond_query_by_name(name_a)
        WebDriverWait(self.driver, timeout=10).until(ec.presence_of_element_located((By.XPATH, "html/body/div[3]/div[2]/div[2]/table/tbody/tr/td[15]/a[1]")),
                            message="请求超时！").click()
        time.sleep(3)
        # 电表类型
        if name_a == '电表类型':
            dev_second = WebDriverWait(self.driver, timeout=10).until(
                ec.presence_of_element_located((By.ID, "selDevSecond")),
                message="请求超时！")
            option_types = dev_second.find_elements_by_tag_name('option')
            for types in option_types:
                if types.text == name_b.decode('utf-8'):
                    types.click()
                    break

    def delete_by_name(self,name):
        try:
            self.cond_query_by_name(name)
            time.sleep(4)
            # delete_btn = WebDriverWait(self.driver,timeout=10).until(ec.presence_of_element_located((By.XPATH, 'html/body/div[3]/div[2]/div[2]/table/tbody/tr/td[15]/a[2]')),
            #                                             message='请求超时')
            # delete_btn = self.driver.find_element_by_xpath('html/body/div[3]/div[2]/div[2]/table/tbody/tr/td[15]/a[2]')
            find_name = self.driver.find_element_by_xpath('html/body/div[3]/div[2]/div[2]/table/tbody/tr/td[3]').text
            assert str(name).decode('utf-8') in find_name
            time.sleep(3)
            # self.cond_add(name)
            # time.sleep(4)
            # self.cond_query_by_name(name)
            delete_btn = WebDriverWait(self.driver, timeout=10).until(
                ec.presence_of_element_located((By.XPATH, 'html/body/div[3]/div[2]/div[2]/table/tbody/tr/td[15]/a[2]')),
                message='请求超时')
            delete_btn.click()
            time.sleep(2)
            alt = self.driver.switch_to_alert()
            alt.accept()
            time.sleep(2)
        except Exception as e:
            print ("删除对象不存在,不需要删除", e.message)

    def check_result_by_name(self, name):
        self.cond_query_by_name(name)
        try:
            result = self.driver.find_element_by_xpath("html/body/div[3]/div[2]/div[2]/table/tbody/tr[1]/td[3]").text
            if result == name.decode('utf-8'):
                print ("查询成功，有满足条件的记录")
            else:
                print ("查询失败，无满足条件的记录")
        except Exception as e:
            print ("查询异常", e)

    def check_reset(self):
        model_code = WebDriverWait(self.driver, timeout=10).until(ec.presence_of_element_located((By.ID, 'txtKeyword')),
                                                                  message=u"元素加载超时！")
        assert model_code.text in u""
        phase = self.driver.find_element_by_id("queryPhase").find_elements_by_tag_name("option")[0].text
        assert phase in u"全部"
        second = self.driver.find_element_by_id("queryDevSecond").find_elements_by_tag_name("option")[0].text
        assert second in u"全部"
        dev_type = self.driver.find_element_by_id("queryDevType").find_elements_by_tag_name("option")[0].text
        assert dev_type in u"全部"
        factory = self.driver.find_element_by_id("queryFactory").find_elements_by_tag_name("option")[0].text
        assert factory in u"全部厂商"

    def check_result(self):
        try:
            result = self.driver.find_element_by_xpath("html/body/div[3]/div[2]/div[2]/table/tbody/tr[1]/td[3]").text
            self.assertNotEquals(result, u"暂无数据信息", msg="MSG查询有相应数据")
            if u"暂无数据信息" == result:
                print ("查询失败，无满足条件的记录")
            else:
                print ("查询成功，有满足条件的记录")

        except:
            print ("查询异常")

    def check_modify(self, modify_name, name_a, name_b):
        # modify_name 是修改对象 name_a 是修改对应的型号编码 name_b 修改后的值
        self.cond_query_by_name(name_a)
        time.sleep(5)
        try:
            result = self.driver.find_element_by_xpath(
                "html/body/div[3]/div[2]/div[2]/table/tbody/tr/td[3]").text
            self.assertNotEquals(result, u"暂无数据信息", msg="MSG查询有相应数据")
            if u"暂无数据信息" == result:
                print (u"查询失败，无满足条件的记录")
            else:
                count = ""
                if modify_name == "型号编码":
                    count = self.driver.find_element_by_xpath(
                        "html/body/div[3]/div[2]/div[2]/table/tbody/tr/td[3]").text
                if modify_name == "电表类型":
                    count = self.driver.find_element_by_xpath(
                        "html/body/div[3]/div[2]/div[2]/table/tbody/tr/td[5]").text
                if modify_name == "测量类型":
                    count = self.driver.find_element_by_xpath(
                        "html/body/div[3]/div[2]/div[2]/table/tbody/tr/td[6]").text
                if modify_name == "最大电流规格":
                    count = self.driver.find_element_by_xpath(
                        "html/body/div[3]/div[2]/div[2]/table/tbody/tr/td[7]").text
                if modify_name == "最大充值金额":
                    count = self.driver.find_element_by_xpath(
                        "html/body/div[3]/div[2]/div[2]/table/tbody/tr/td[8]").text
                if modify_name == "单次最大充值金额":
                    count = self.driver.find_element_by_xpath(
                        "html/body/div[3]/div[2]/div[2]/table/tbody/tr/td[9]").text
                if modify_name == "合闸方式":
                    count = self.driver.find_element_by_xpath(
                        "html/body/div[3]/div[2]/div[2]/table/tbody/tr/td[10]").text
                if modify_name == "规范类型 ":
                    count = self.driver.find_element_by_xpath(
                        "html/body/div[3]/div[2]/div[2]/table/tbody/tr/td[11]").text
                if modify_name == "设备厂家名称":
                    count = self.driver.find_element_by_xpath(
                        "html/body/div[3]/div[2]/div[2]/table/tbody/tr/td[12]").text

                assert count in name_b.decode('utf-8')
                print ("查询成功，有满足条件的记录")

        except Exception as e:
            print ("查询异常", e)

    def check_by_name(self,name):
        self.cond_query_by_name(name)
        time.sleep(3)
        try:
            result = self.driver.find_element_by_xpath(
                "html/body/div[3]/div[2]/div[2]/table/tbody/tr/td").text
            if u"暂无数据信息" == result:
                print (u"删除成功")
            else:
                print (u"删除失败")
        except Exception as e:
            print ("查询异常", e)