#coding:utf-8
import time,sys
from datetime import datetime
sys.path.append("D:\\auto_framework\\Page_Object")
from Page_Object.Page_Base import Page_Base
from selenium.webdriver.common.by import By
from selenium.webdriver.support.wait import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.by import By

class tariff_management(Page_Base):

    def cond_query(self):
        # passdriver = WebDriverWait(self.driver, timeout=10).until(ec.presence_of_element_located((By.ID, 'txtKeyword')),
        #                                                           message=u"元素加载超时！")
        # passdriver.send_keys("")
        # self.driver.find_element_by_id("queryPhase").find_elements_by_tag_name("option")[2].click()
        # self.driver.find_element_by_id("queryDevSecond").find_elements_by_tag_name("option")[2].click()
        # self.driver.find_element_by_id("queryDevType").find_elements_by_tag_name("option")[2].click()
        # self.driver.find_element_by_id("queryFactory").find_elements_by_tag_name("option")[1].click()
        # self.driver.find_element_by_id('btnQuery').click()

        print ("ybc1")
        time.sleep(5)
        tree = self.driver.find_element_by_xpath("//div[@id='tree-container']/li[11]/div")
        tree.click()
        print ("ybc2")

        self.driver.find_element_by_xpath("//*[@id='list_price']/tbody/tr[1]/td[10]/a[1]").click()
        print ("ybc3")
        time.sleep(5)
        self.driver.find_element_by_xpath("//*[@id='editTimeTemplate']/div[4]/select").find_elements_by_tag_name("option")[0].click()
        print ("ybc4")
        passdriver = self.driver.find_element_by_class_name("jcDateIco")
        passdriver.clear()
        passdriver.send_keys("2017-12-20")
        commdriver = self.driver.find_element_by_class_name("inputss")
        commdriver.clear()
        commdriver.send_keys("2")
        self.driver.find_element_by_id("confirmBtn").click()
        time.sleep(20)
        comfirm = self.driver.switch_to_alert()
        comfirm.accept()


    def check_result(self):
        try:
            Result = self.driver.find_element_by_xpath(".//*[@id='list_price']/tbody/tr[1]/td[7]/span[2]").text
            self.assertNotEquals(Result, 2, msg="MSG查询有相应数据")
            #print("Result=%s" %Result)
            if (u"暂无数据信息" == Result):
                print ("费率设置失败，无满足条件的记录")
            else:
                print ("费率设置成功，有满足条件的记录")

        except:
            print ("费率设置异常")



