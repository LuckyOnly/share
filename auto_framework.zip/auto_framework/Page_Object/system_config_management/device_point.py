#-*- coding: UTF-8 -*-'
import os
from time import sleep
from selenium.webdriver.support.select import Select
from Page_Object.Page_Base import Page_Base, find_element


class device_point(Page_Base):
    def AddVirtual(self, content):
        # 测试新增
        self.locate_element('name').clear()  # 输入点位名称
        self.locate_element('name').send_keys(content[0])
        s = self.locate_element('type')  # 点位类型
        s.select_by_index(0)
        self.locate_element('area').click()  # 选择区域
        self.selectTreeArea(content[1])
        self.locate_element('classification').click()  # 选择分类分项
        self.selectTreeArea(content[2])
        self.locate_element('organization').click()  # 选择组织维度
        self.selectTreeArea(content[3])
        self.locate_element('formats').click()  # 选择业态维度
        self.selectTreeArea(content[4])
        s = self.locate_element('url1')  # 选择设备的url
        s.select_by_index(content[5])
        self.locate_element('url3').clear()
        self.locate_element('url3').send_keys(content[6])
        self.locate_element('description').clear()
        self.locate_element('description').send_keys(content[7])  # 填写描述
        self.locate_element('expression').clear()
        self.locate_element('expression').send_keys(content[8])   # 输入公式
        self.locate_element('submit').click()  # 刷出点位绑定
        if content[9] == 1:
            self.locate_element('enable').click()  # 启用点位
        find_element(self.driver, 'xpath', ".//*[@id='id_0']").click()
        sleep(1)
        find_element(self.driver, 'xpath', ".//*[@id='formulaNameMes']/tbody/tr[" + str(content[10]) + "]/td[1]").click()  # 选择对应的物理点位，只有一个可选是什么鬼
        self.locate_element('submit').click()  # 点击确定
        sleep(2)
        self.get_element('confirm').click()  # 点击添加成功的确定

    def AddPhysical(self, content):
        self.locate_element('name').clear()  # 输入点位名称
        self.locate_element('name').send_keys(content[0])
        s = self.locate_element('type')  # 点位类型
        s.select_by_index(1)  # 物理点位
        self.locate_element('area').click()  # 选择区域
        self.selectTreeArea(content[1])
        self.locate_element('classification').click()  # 选择分类分项
        self.selectTreeArea(content[2])
        self.locate_element('organization').click()  # 选择组织维度
        self.selectTreeArea(content[3])
        self.locate_element('formats').click()  # 选择业态维度
        self.selectTreeArea(content[4])
        s = self.locate_element('url1')  # 选择设备的url
        s.select_by_index(content[5])
        self.locate_element('url3').clear()
        self.locate_element('url3').send_keys(content[6])
        self.locate_element('description').clear()
        self.locate_element('description').send_keys(content[7])  # 填写描述
        if content[8] == 1:
            self.locate_element('enable').click()  # 启用点位
        self.locate_element('submit').click()  # 点击确定
        sleep(2)
        self.click_button('确定')
        #self.get_element('confirm').click()  # 点击添加成功的确定

    def Search(self, content):
        # 测试搜索
        self.driver.execute_script("window.scrollTo(0,0);")  # 滑到顶部
        self.locate_element('keyword').clear()  # 输入搜索的点位名称
        self.locate_element('keyword').send_keys(content[0])
        s = self.locate_element('ifable')
        s.select_by_index(content[1])  # 搜索启用的点位
        self.driver.execute_script("window.scrollTo(0,0);")  # 滑到顶部
        self.driver.execute_script("document.getElementById('startTime').removeAttribute('readonly')")  # 移除该文本框的只读属性
        self.get_element('startTime').clear()  # 选择开始时间
        self.get_element('startTime').send_keys(content[2])
        self.driver.execute_script("document.getElementById('endTime').removeAttribute('readonly')")  # 移除该文本框的只读属性
        self.get_element('endTime').clear()  # 选择结束时间
        self.get_element('endTime').send_keys(content[3])
        self.get_element('search').click()  # 点击搜索
        print(u"搜索功能测试通过")

    def Edit(self, content):
        # 测试编辑功能
        if content[0] == 1:
            self.locate_element('enable').click()  # 修改启用禁用状态
        # find_element(self.driver, 'xpath', ".//*[@id='calculatorView']").clear()
        # 修改公式，这里通过下方的按钮进行添加
        # 算了，暂时先不改公式吧，一改就等于重写啊
        self.locate_element('submit').click()  # 点击确定
        sleep(2)
        self.get_element('confirm').click()  # 点击提交成功的确定
        print(u"编辑功能测试通过")

    def Enable(self, indexes):
        # 测试启用禁用
        self.driver.execute_script("window.scrollTo(0,0);")  # 滑到顶部
        for i in indexes:
            self.get_element("checkbox_in_table", [i, 1]).click()
        self.get_element("link", u"批量启用").click()  # 选择批量启用
        sleep(1)
        self.get_element('confirm').click()  # 选择确定
        sleep(1)
        self.get_element('confirm').click()  # 选择确定
        sleep(1)

    def Disable(self, indexes):
        self.driver.execute_script("window.scrollTo(0,0);")  # 滑到顶部
        for i in indexes:
            self.get_element("checkbox_in_table", [i, 1]).click()
        self.get_element("link", u"批量禁用").click()  # 选择批量禁用
        sleep(1)
        self.get_element('confirm').click()  # 选择确定
        sleep(1)
        self.get_element('confirm').click()  # 选择确定
        sleep(1)
        print(u"批量禁用测试通过")

    def Load(self):
        # 测试导入和下载
        self.get_element("link", u"导入").click()  # 点击导入
        sleep(2)
        self.driver.switch_to.frame(self.get_element("frame"))
        self.get_element("link", u"下载模板").click()  # 点击下载模板
        sleep(1)  # 自动下载
        print(u"下载模板测试通过")
        self.locate_element('upfile').click()  # 点击上传
        sleep(5)
        os.system("D:/upload_devicepoint.exe")  # 上传回路
        sleep(4)
        find_element(self.driver, 'xpath', ".//*[@id='upload']").click()  # 点击确定
        sleep(3)
        self.get_element('confirm').click()
        self.driver.switch_to.default_content()  # 切回原来的
        sleep(3)
        print(u"批量上传测试通过")

    def locate_element(self, name, args=[]):
        if name == 'name':
            return find_element(self.driver, 'xpath', ".//*[@id='formula_name']")
        if name == 'type':
            return Select(find_element(self.driver, 'xpath', ".//*[@id='pointType']"))  # 点位类型
        if name == 'area':
            return find_element(self.driver, 'xpath', ".//*[@id='area']")  # 选择区域
        if name == 'classification':
            return find_element(self.driver, 'xpath', ".//*[@id='Classification']")  # 选择分类分项
        if name == 'organization':
            return find_element(self.driver, 'xpath', ".//*[@id='Organization']")  # 选择组织维度
        if name == 'formats':
            return find_element(self.driver, 'xpath', ".//*[@id='formats']")  # 选择业态维度
        if name == 'url1':
            return Select(find_element(self.driver, 'xpath', ".//*[@id='urlBuild']"))  # 选择设备的url
        if name == 'url3':
            return find_element(self.driver, 'xpath', ".//*[@id='uri3']")
        if name == 'description':
            return find_element(self.driver, 'xpath', ".//*[@id='describe']")
        if name == 'expression':
            return find_element(self.driver, 'xpath', ".//*[@id='calculatorView']")
        if name == 'clear_all':
            return find_element(self.driver, 'xpath', ".//*[@id='clearAll']")
        if name == 'binder_group':
            return find_element(self.driver, 'xpath', ".//*[@id='calculatorShow']/td[2]/div")
        if name == 'binder':
            return find_element(self.driver, 'xpath', ".//*[@id='id_" + str(args) + "']")
        if name == 'binder_option':
            return find_element(self.driver, 'xpath', ".//*[@id='formulaNameMes']/tbody/tr[" + str(args) + "]/td[1]")
        if name == 'submit':
            return find_element(self.driver, 'xpath', ".//*[@id='submit_form']")  # 刷出点位绑定
        if name == 'cancle':
            return find_element(self.driver, 'xpath', "html/body/div[2]/a[2]")
        if name == 'enable':
            # //td[text()='是否启用：']/following::label
            return find_element(self.driver, 'xpath', ".//*[@id='formulaFrom']/table[1]/tbody/tr[9]/td[2]/label")  # 启用点位
        if name == 'keyword':
            return find_element(self.driver, 'xpath', ".//*[@id='point_name']")
        if name == 'ifable':
            return Select(find_element(self.driver, 'xpath', ".//*[@id='enable']"))

        if name == 'span_name':
            return find_element(self.driver, 'xpath', ".//*[@id='formulaFrom']/table[1]/tbody/tr[1]/td[2]/span")
        if name == 'span_classification':
            return find_element(self.driver, 'xpath', ".//*[@id='formulaFrom']/table[1]/tbody/tr[4]/td[2]/span[2]")
        if name == 'span_url':
            return find_element(self.driver, 'xpath', ".//*[@id='formulaFrom']/table[1]/tbody/tr[8]/td[2]/span")
        if name == 'span_expression':
            return find_element(self.driver, 'xpath', ".//*[@id='calculatorBtnShow']/td[2]/span")
        if name == 'span_enable':
            return find_element(self.driver, 'xpath', ".//*[@id='formulaFrom']/table[1]/tbody/tr[9]/td[2]/div/div")

        if name == 'upfile':
            return find_element(self.driver, 'xpath', ".//*[@id='upfile']/div/a[1]")