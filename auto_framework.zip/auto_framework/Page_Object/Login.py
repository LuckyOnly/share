#coding:utf-8

from selenium.webdriver.common.by import By
from selenium.webdriver.common.action_chains import ActionChains
import time
from Page_Base import  Page_Base

class login(Page_Base):

    login_username_loc=(By.ID,'username')
    login_password_loc=(By.ID,'password')
    login_force_loc=(By.ID,'forceLogin')
    login_button_loc=(By.ID,'loginButton')

    # 输入用户名
    def login_username(self,username):
        self.find_element(*self.login_username_loc).send_keys(username)

    #输入密码
    def login_password(self,password):
        self.find_element(*self.login_password_loc).send_keys(password)

    #勾选强制登录
    def login_force(self):
        self.find_element(*self.login_force_loc).click()

    #点击登录按钮
    def login_button(self):
        self.find_element(*self.login_button_loc).click()

    login_error_hint_loc=(By.ID,'loginError')

    #定义统一登录入口
    def  user_login(self,username='username',password='password'):
        self.login_username(username)
        self.login_password(password)
        self.login_force()
        self.login_button()
        time.sleep(2)

    #错误提示
    def login_error_hint(self):
        return  self.find_element(*self.login_error_hint_loc).text










