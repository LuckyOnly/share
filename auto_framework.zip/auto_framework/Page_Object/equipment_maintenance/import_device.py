# coding:utf-8

import os
import time
from Page_Object.Page_Base import Page_Base
from selenium.webdriver.support.wait import WebDriverWait
from selenium.webdriver.support import expected_conditions as ec
from selenium.webdriver.common.by import By
from selenium.webdriver.support.select import Select


class ImportDevice(Page_Base):
    # 电表导入
    def set_group_name(self, name):
        # 设置广场的名字
        js = "var choseContent=$('#s2id_sltPlaza>a>span'); " \
             "choseContent[0].innerText='" + name + "';" \
                                                    "$('#s2id_sltPlaza>a')[0].click();"
        self.driver.execute_script(js)

    def set_add_name(self, name):
        js = "var addbtn=$('#s2id_sltIsAdd>a>span');" \
             "addbtn[0].innerText='" + name + "';" \
                                              "$('#s2id_sltIsAdd>a')[0].click();"
        self.driver.execute_script(js)

    def cond_query(self):
        driver = self.driver
        s1 = driver.find_element_by_id('sltPlaza')
        Select(s1).select_by_visible_text("长沙开福万达广场")
        s2 = driver.find_element_by_id('sltIsAdd')
        Select(s2).select_by_visible_text("是")
        plaza_name = WebDriverWait(self.driver, timeout=10).until(
            ec.presence_of_element_located((By.ID, "UpImagePath")),
            message=u'元素加载超时！')
        # 上传绝对路径
        path = os.getcwd()
        path1 = path + '\\file\\20171208.xls'
        plaza_name.send_keys(path1)
        device_status = WebDriverWait(self.driver, timeout=10).until(
            ec.presence_of_element_located((By.ID, "BtnUpload")),
            message=u'元素加载超时！')
        device_status.click()
        time.sleep(3)
        driver.switch_to_alert().accept()
        time.sleep(3)
        driver.switch_to_alert().accept()
        time.sleep(10)

    def check_result(self):
        try:
            result = self.driver.find_element_by_xpath(
                'html/body/div[1]/div[3]/div/div/div[2]/div/div/div[2]/table/tbody/tr/td[3]')
            if result.text == u'导入成功':
                print ("操作成功")
            else:
                print ('操作失败')
        except Exception as e:
            print ("查询异常", e.message)
