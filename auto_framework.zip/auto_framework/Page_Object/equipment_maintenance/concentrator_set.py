#coding:utf-8


import time,sys
sys.path.append("D:\\auto_framework\\Page_Object")
from Page_Object.Page_Base import Page_Base
from selenium.webdriver.common.by import By
from selenium.webdriver.support.wait import WebDriverWait
from selenium.webdriver.support import expected_conditions as ec
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import Select
class concentrator_set(Page_Base):

    def cond_query(self, chose_name, type_name):

        #查找元素
        if chose_name.decode("utf-8") == u"广场名称":
            plaza_names = WebDriverWait(self.driver, timeout=10).until(ec.presence_of_element_located((By.ID,"sltPlaza")),
                                                                       message="请求超时")
            options = plaza_names.find_elements_by_tag_name("option")
            for type in options:
                # print type.text
                if type_name.decode('utf-8') == type.text:
                    type.click()
                    time.sleep(13)
        if chose_name.decode("utf-8") == u"集中器类型":
            plaza_names = WebDriverWait(self.driver, timeout=10).until(ec.presence_of_element_located((By.ID,"sltStationType")),
                                                                       message="请求超时")
            options = plaza_names.find_elements_by_tag_name("option")
            for type in options:
                # print type.text
                if type_name.decode('utf-8') == type.text:
                    type.click()
                    time.sleep(13)
        if chose_name.decode("utf-8") == u"通讯状态":
            plaza_names = WebDriverWait(self.driver, timeout=10).until(ec.presence_of_element_located((By.ID,"sltDeviceStatus")),
                                                                       message="请求超时")
            time.sleep(3)
            options = plaza_names.find_elements_by_tag_name("option")
            for type in options:
                # print type.text
                if type_name.decode('utf-8') == type.text:
                    type.click()
                    time.sleep(13)
        if chose_name.decode("utf-8") == u"设备厂家":
            plaza_names = WebDriverWait(self.driver, timeout=10).until(ec.presence_of_element_located((By.ID,"sltFactorySearch")),
                                                                       message="请求超时")
            options = plaza_names.find_elements_by_tag_name("option")
            for type in options:
                # print type.text
                if type_name.decode('utf-8') == type.text:
                    type.click()
                    time.sleep(13)
        if chose_name.decode("utf-8") == u"型号":
            type_name = "南京天溯"
            plaza_names = WebDriverWait(self.driver, timeout=10).until(ec.presence_of_element_located((By.ID,"sltFactorySearch")),
                                                                       message="请求超时")
            options = plaza_names.find_elements_by_tag_name("option")
            for type in options:
                # print type.text
                if type_name.decode('utf-8') == type.text:
                    type.click()
                    time.sleep(13)
            plaza_names = WebDriverWait(self.driver, timeout=10).until(ec.presence_of_element_located((By.ID,"sltStationTypeSearch")),
                                                                       message="请求超时")
            options = plaza_names.find_elements_by_tag_name("option")
            for type in options:
                # print type.text
                if type_name.decode('utf-8') == type.text:
                    type.click()
                    time.sleep(13)
        if chose_name.decode("utf-8") == u"集中器地址":
            passdriver = WebDriverWait(self.driver, timeout=10).until(ec.presence_of_element_located((By.ID, 'Address')),
                                                                      message=u"元素加载超时！")
            passdriver.send_keys("10001")
        time.sleep(7)
        btn = self.driver.find_element_by_id('search-btn')
        btn.click()
        time.sleep(8)

    def cond_query1(self):
        #进入一键测试
        passdriver = WebDriverWait(self.driver, timeout=10).until(ec.presence_of_element_located((By.ID, 'Address')),
                                                                  message=u"元素加载超时！")
        passdriver.click()
        passdriver.send_keys('1')
        time.sleep(5)
        self.driver.find_element_by_id('search-btn').click()
        #一键测试
        Result = self.driver.find_element_by_xpath(
            "html/body/div[1]/div[3]/div/div[3]/div[2]/table/tbody/tr[1]/td[13]/span[3]")
        Result.click()
        self.assertNotEquals(Result.text, u"暂无数据信息", msg="MSG查询有相应数据")
        time.sleep(25)
        Info = self.driver.find_element_by_id('ui-id-2').text

        assert u'设备档案' in Info

    def dele_equip(self, Cname):
        #删除设备
        deviceList=self.driver.find_element_by_id('stationDeviceList')

        js="var names=$('#stationDeviceList tr td');" \
           "for(var i=0;i<names.length/8;i++){" \
           "if(names[2+i*8].innerText==='"+Cname+"'){" \
           " console.log('true');" \
           "var edit=names[7+i*8].getElementsByClassName('dialog-adelete operater');" \
           "edit[0].click();" \
            "}" \
            "}";
        self.driver.execute_script(js);
        # dele=self.driver.find_element_by_xpath('html/body/div[4]/div[2]/table/tbody/tr[1]/td[8]/span[2]')
        # dele.click()

    def add_equip(self, Cname):
        #add the equipment
        addEquip=self.driver.find_element_by_xpath('html/body/div[4]/div[2]/div[1]/span[1]/a')
        addEquip.click()
        sele=self.driver.find_element_by_id('sltDevice1')
        Select(sele).select_by_visible_text(Cname)
        btn=self.driver.find_element_by_xpath('html/body/div[4]/div[2]/table/tbody/tr[1]/td[8]/a')

        btn.click()
        time.sleep(6)

    def dele_result(self, Cname):
        self.cond_query1();

    def check_result1(self):
        try:
            result = self.driver.find_element_by_xpath(
                "html/body/div[1]/div[3]/div/div[3]/div[2]/table/tbody/tr[1]/td[13]/span[3]")

            result.click()
            self.assertNotEquals(result.text, u"暂无数据信息", msg="MSG查询有相应数据")
            time.sleep(20)
            Info=self.driver.find_element_by_id('ui-id-2').text
            assert u'设备档案' in Info

            #print("result=%s" %result)
            if (u"暂无数据信息" == result):
                print ("查询失败，无满足条件的记录")
            else:
                print ("查询成功，有满足条件的记录")
        except Exception as e:
            print ("查询异常", e)

    def check_result(self):
        try:
            result = self.driver.find_element_by_xpath(
                ".//*[@id='dataList']/tr[1]/td[3]")
            self.assertNotEquals(result.text, u"暂无数据信息", msg="MSG查询有相应数据")
            if u"暂无数据信息" == result:
                print ("查询失败，无满足条件的记录")
            else:
                print ("查询成功，有满足条件的记录")
        except Exception as e:
            print ("查询异常", e)