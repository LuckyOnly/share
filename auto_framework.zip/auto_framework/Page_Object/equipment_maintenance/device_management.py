# coding:utf-8

import time, sys
from Page_Object.Page_Base import Page_Base
from selenium.webdriver.support.wait import WebDriverWait
from selenium.webdriver.support import expected_conditions as ec
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import Select


class DeviceManagement(Page_Base):
    def cond_query_by_name(self, chose_name):
        time.sleep(4)
        if chose_name.decode('utf-8') == u'设备厂商':
            dev_factory = WebDriverWait(self.driver, timeout=10).until(
                ec.presence_of_element_located((By.ID, "sltDevFactorySearch")),
                message=u'元素加载超时！')
            dev_factory.find_elements_by_tag_name("option")[1].click()
        if chose_name.decode('utf-8') == u'电表编号':
            device_no = WebDriverWait(self.driver, timeout=10).until(
                ec.presence_of_element_located((By.ID, "deviceNoSearch")),
                message=u'元素加载超时！')
            device_no.send_keys("240ZF170815013")
        if chose_name.decode('utf-8') == u'电表名称':
            device_no = WebDriverWait(self.driver, timeout=10).until(
                ec.presence_of_element_located((By.ID, "deviceNoSearch")),
                message=u'元素加载超时！')
            device_no.send_keys("WS30000")
        self.driver.find_element_by_id('search-btn').click()
        time.sleep(5)

    def cond_query(self):
        device_status = WebDriverWait(self.driver, timeout=10).until(
            ec.presence_of_element_located((By.ID, "sltDeviceStatus")),
            message=u'元素加载超时！')
        device_status.find_elements_by_tag_name("option")[2].click()
        dev_type = WebDriverWait(self.driver, timeout=10).until(
            ec.presence_of_element_located((By.ID, "sltDevTypeSearch")),
            message=u'元素加载超时！')
        dev_type.find_elements_by_tag_name("option")[1].click()
        device_no = WebDriverWait(self.driver, timeout=10).until(
            ec.presence_of_element_located((By.ID, "deviceNoSearch")),
            message=u'元素加载超时！')
        device_no.send_keys("000016088618")
        self.driver.find_element_by_id('search-btn').click()
        time.sleep(3)

    def add_device(self,name):
        try:
            time.sleep(2)
            add_btn = WebDriverWait(self.driver,timeout=10).until(ec.presence_of_element_located((By.XPATH, ".//*[@id='ToolBar_AddDevice']"))
                                                                  , message="请求超时！")
            add_btn.click()
            time.sleep(5)
            # 电表编号
            device_num = WebDriverWait(self.driver, timeout=10).until(
                ec.presence_of_element_located((By.ID, "txtDeviceNum"))
                , message="请求超时！")
            # device_address.clear()
            device_num.send_keys(name)
            time.sleep(2)
            # 广场名称
            device_plaza = WebDriverWait(self.driver, timeout=10).until(
                ec.presence_of_element_located((By.ID, "selectPlaza"))
                , message="请求超时！")
            device_plaza.find_elements_by_tag_name('option')[14].click()
            time.sleep(2)
            # 设备厂家
            device_factory = WebDriverWait(self.driver, timeout=10).until(
                ec.presence_of_element_located((By.ID, "sltDevFactory"))
                , message="请求超时！")
            device_factory.find_elements_by_tag_name('option')[1].click()
            time.sleep(2)
            # 电表型号
            device_type = WebDriverWait(self.driver, timeout=10).until(
                ec.presence_of_element_located((By.ID, "sltDevType"))
                , message="请求超时！")
            device_type.find_elements_by_tag_name('option')[2].click()
            time.sleep(2)
            # 所属集中器
            device_station = WebDriverWait(self.driver, timeout=10).until(
                ec.presence_of_element_located((By.ID, "sltStation"))
                , message="请求超时！")
            device_station.find_elements_by_tag_name('option')[1].click()
            time.sleep(2)
            # 通讯通道号
            device_channel =  WebDriverWait(self.driver, timeout=10).until(
                ec.presence_of_element_located((By.ID, "sltChannel"))
                , message="请求超时！")
            device_channel.find_elements_by_tag_name('option')[2].click()
            time.sleep(2)
            # 通道地址
            device_address = WebDriverWait(self.driver, timeout=10).until(
                ec.presence_of_element_located((By.ID, "txtAddress"))
                , message="请求超时！")
            device_address.clear()
            device_address.send_keys(name)
            time.sleep(2)
            # 设备名称
            device_txt_name = WebDriverWait(self.driver, timeout=10).until(
                ec.presence_of_element_located((By.ID, "txtDeviceName"))
                , message="请求超时！")
            device_txt_name.clear()
            device_txt_name.send_keys('WS30000')
            time.sleep(3)
            # 品牌
            device_brand_name = WebDriverWait(self.driver, timeout=10).until(
                ec.presence_of_element_located((By.ID, "txtBrand"))
                , message="请求超时！")
            device_brand_name.clear()
            device_brand_name.send_keys(u'567慕斯')
            # 变比
            devrate = WebDriverWait(self.driver, timeout=10).until(
                ec.presence_of_element_located((By.ID, "txtDevrate"))
                , message="请求超时！")
            devrate.send_keys('1')
            time.sleep(2)
            # 楼层
            dev_floor = WebDriverWait(self.driver, timeout=10).until(
                ec.presence_of_element_located((By.ID, "txtDevfloor"))
                , message="请求超时！")
            dev_floor.send_keys('1')
            time.sleep(2)
            # 井号
            dev_well = WebDriverWait(self.driver, timeout=10).until(
                ec.presence_of_element_located((By.ID, "txtDevwell"))
                , message="请求超时！")
            dev_well.send_keys('1')
            # 箱号
            dev_box = WebDriverWait(self.driver, timeout=10).until(
                ec.presence_of_element_located((By.ID, "txtDevbox"))
                , message="请求超时！")
            dev_box.send_keys('1')
            # 提交
            confirm_btn = WebDriverWait(self.driver,timeout=10).until(ec.presence_of_element_located((By.XPATH, "html/body/div[3]/div[3]/div/button[1]"))
                                                                  , message="请求超时！")
            time.sleep(2)
            confirm_btn.click()
            time.sleep(25)
        except Exception as e:
            print ('电表存在',e)

    def modify_device(self,chose_name, id_name, type_name):
        self.cond_by_name(id_name)
        # 修改
        modify_btn = WebDriverWait(self.driver,timeout=10).until(ec.presence_of_element_located((By.XPATH,".//*[@id='dataList']/tr[1]/td[19]/span[1]/span")),
                                                                 message="请求超时")
        modify_btn.click()
        time.sleep(5)
        if chose_name.decode('utf-8') == u"型号":
            #型号
            device_type = WebDriverWait(self.driver, timeout=10).until(
                ec.presence_of_element_located((By.ID, "sltDevType"))
                , message="请求超时！")
            options = device_type.find_elements_by_tag_name('option')
            for type in options:
                # print type.text
                if type_name.decode('utf-8') == type.text:
                    type.click()
                    time.sleep(13)
        if chose_name.decode('utf-8') == u"通道号":
            # 通道号
            device_channel =  WebDriverWait(self.driver, timeout=10).until(
                ec.presence_of_element_located((By.ID, "sltChannel"))
                , message="请求超时！")
            options = device_channel.find_elements_by_tag_name('option')
            for type in options:
                # print type.text
                if type_name.decode('utf-8') == type.text:
                    type.click()
                    time.sleep(13)
        if chose_name.decode('utf-8') == u"楼层":
            dev_floor = WebDriverWait(self.driver, timeout=10).until(
                ec.presence_of_element_located((By.ID, "txtDevfloor"))
                , message="请求超时！")
            dev_floor.clear()
            dev_floor.send_keys(type_name)
        if chose_name.decode('utf-8') == u"井号":
            dev_floor = WebDriverWait(self.driver, timeout=10).until(
                ec.presence_of_element_located((By.ID, "txtDevwell"))
                , message="请求超时！")
            dev_floor.clear()
            dev_floor.send_keys(type_name)
        if chose_name.decode('utf-8') == u"箱号":
            dev_floor = WebDriverWait(self.driver, timeout=10).until(
                ec.presence_of_element_located((By.ID, "txtDevbox"))
                , message="请求超时！")
            dev_floor.clear()
            dev_floor.send_keys(type_name)
        if chose_name.decode('utf-8') == u"变比":
            dev_floor = WebDriverWait(self.driver, timeout=10).until(
                ec.presence_of_element_located((By.ID, "txtDevrate"))
                , message="请求超时！")
            dev_floor.clear()
            dev_floor.send_keys(type_name)
        if chose_name.decode('utf-8') == u"通道地址":
            dev_floor = WebDriverWait(self.driver, timeout=10).until(
                ec.presence_of_element_located((By.ID, "txtAddress"))
                , message="请求超时！")
            dev_floor.clear()
            dev_floor.send_keys(type_name)
        if chose_name.decode('utf-8') == u"设备名称":
            dev_floor = WebDriverWait(self.driver, timeout=10).until(
                ec.presence_of_element_located((By.ID, "txtDeviceName"))
                , message="请求超时！")
            dev_floor.clear()
            dev_floor.send_keys(type_name)

        # 提交
        confirm_btn = WebDriverWait(self.driver, timeout=10).until(
            ec.presence_of_element_located((By.XPATH, "html/body/div[3]/div[3]/div/button[1]"))
            , message="请求超时！")
        time.sleep(2)
        confirm_btn.click()

    def check_modify(self,chose_name,id_name, type_name):
        time.sleep(6)
        if chose_name.decode('utf-8') == u"楼层":
            dev_floor = WebDriverWait(self.driver, timeout=10).until(
                ec.presence_of_element_located((By.XPATH, ".//*[@id='dataList']/tr/td[15]"))
                , message="请求超时！")
            print type_name.decode('utf-8') , dev_floor.text
            assert type_name.decode('utf-8') in dev_floor.text
        if chose_name.decode('utf-8') == u"型号":
            # 型号
            device_type = WebDriverWait(self.driver, timeout=10).until(
                ec.presence_of_element_located((By.XPATH, ".//*[@id='dataList']/tr/td[4]"))
                , message="请求超时！")
            assert type_name.decode('utf-8') in device_type.text
        if chose_name.decode('utf-8') == u"通道号":
            device_type = WebDriverWait(self.driver, timeout=10).until(
                ec.presence_of_element_located((By.XPATH, ".//*[@id='dataList']/tr/td[5]"))
                , message="请求超时！")
            print type_name.decode('utf-8'), device_type.text
            assert type_name.decode('utf-8') in device_type.text
        if chose_name.decode('utf-8') == u"井号":
            device_type = WebDriverWait(self.driver, timeout=10).until(
                ec.presence_of_element_located((By.XPATH, ".//*[@id='dataList']/tr[1]/td[16]"))
                , message="请求超时！")
            print type_name.decode('utf-8'), device_type.text
            assert type_name.decode('utf-8') in device_type.text
        if chose_name.decode('utf-8') == u"箱号":
            device_type = WebDriverWait(self.driver, timeout=10).until(
                ec.presence_of_element_located((By.XPATH, ".//*[@id='dataList']/tr[1]/td[17]"))
                , message="请求超时！")
            print type_name.decode('utf-8'), device_type.text
            assert type_name.decode('utf-8') in device_type.text
        if chose_name.decode('utf-8') == u"变比":
            device_type = WebDriverWait(self.driver, timeout=10).until(
                ec.presence_of_element_located((By.XPATH, ".//*[@id='dataList']/tr[1]/td[13]"))
                , message="请求超时！")
            print type_name.decode('utf-8'), device_type.text
            assert type_name.decode('utf-8') in device_type.text
        if chose_name.decode('utf-8') == u"通道地址":
            device_type = WebDriverWait(self.driver, timeout=10).until(
                ec.presence_of_element_located((By.XPATH, ".//*[@id='dataList']/tr[1]/td[6]"))
                , message="请求超时！")
            print type_name.decode('utf-8'), device_type.text
            assert type_name.decode('utf-8') in device_type.text
        if chose_name.decode('utf-8') == u"设备名称":
            device_type = WebDriverWait(self.driver, timeout=10).until(
                ec.presence_of_element_located((By.XPATH, ".//*[@id='dataList']/tr[1]/td[7]"))
                , message="请求超时！")
            print type_name.decode('utf-8'), device_type.text
            assert type_name.decode('utf-8') in device_type.text

    def check_cond_result_by_name(self,chose_name):
        try:
            if chose_name.decode('utf-8') == u'设备厂商':
                device_no = WebDriverWait(self.driver, timeout=10).until(ec.presence_of_element_located((By.XPATH, ".//*[@id='dataList']/tr[1]/td[3]")),
                message=u'元素加载超时！')
                print device_no.text
                assert u"南京天溯" in device_no.text
            if chose_name.decode('utf-8') == u'电表编号':
                device_no = WebDriverWait(self.driver, timeout=10).until(ec.presence_of_element_located((By.XPATH, ".//*[@id='dataList']/tr[1]/td[2]")),
                message=u'元素加载超时！')
                assert u"240ZF170815013" in device_no.text
            if chose_name.decode('utf-8') == u'电表名称':
                device_no = WebDriverWait(self.driver, timeout=10).until(ec.presence_of_element_located((By.XPATH, ".//*[@id='dataList']/tr[1]/td[7]")),
                message=u'元素加载超时！')
                assert u"WS30000" in device_no.text
        except Exception as e:
            print ("查询异常", e.message)

    def cond_by_name(self, name):
        time.sleep(30)
        device_no = WebDriverWait(self.driver, timeout=10).until(
            ec.presence_of_element_located((By.ID, "deviceNoSearch")),
            message=u'元素加载超时！')
        device_no.clear()
        device_no.send_keys(name)
        self.driver.find_element_by_id('search-btn').click()
        time.sleep(16)
        result = self.driver.find_element_by_xpath(".//*[@id='dataList']/tr/td[2]")
        time.sleep(3)
        assert str(name).decode('utf-8') in result.text

    def delete_name(self, name):
        try:
            self.cond_by_name(name)
            time.sleep(3)
            confirm_btn = WebDriverWait(self.driver, timeout=10).until(ec.presence_of_element_located((By.XPATH, ".//*[@id='dataList']/tr/td[19]/span[2]/span"))
                                                                  , message="请求超时！")
            time.sleep(2)
            confirm_btn.click()
            alert_btn = self.driver.switch_to_alert()
            alert_btn.accept()
            time.sleep(12)
        except Exception as e:
            print ('没有删除的对象', e)

    def check_result(self):
        try:
            result = self.driver.find_element_by_xpath("//*[@id='dataList']/tr/td").text
            self.assertNotEquals(result, u"暂无数据信息", msg="MSG查询有相应数据")
            if u"暂无数据信息" == result:
                print ("查询失败，无满足条件的记录")
            else:
                print ("查询成功，有满足条件的记录")

        except Exception as e:
            print ("查询异常", e.message)

    def check_result_by_name(self, name):
        time.sleep(4)
        device_no = WebDriverWait(self.driver, timeout=10).until(
            ec.presence_of_element_located((By.ID, "deviceNoSearch")),
            message=u'元素加载超时！')
        device_no.send_keys(name)
        self.driver.find_element_by_id('search-btn').click()
        time.sleep(5)
        try:
            result = self.driver.find_element_by_xpath("//*[@id='dataList']/tr/td").text
            self.assertNotEquals(result, u"暂无数据信息", msg="MSG查询有相应数据")
            if u"暂无数据信息" == result:
                print ("查询成功，满足条件的记录")
                self.add_device(name)
            else:
                print ("查询失败，有满足条件的记录")
        except Exception as e:
            result = self.driver.find_element_by_xpath(".//*[@id='dataList']/tr/td[2]")
            time.sleep(3)
            assert str(name).decode('utf-8') in result.text
            time.sleep(3)
            print ("已存在", e.message)
