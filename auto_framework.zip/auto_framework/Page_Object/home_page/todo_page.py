# coding: utf-8
from Page_Object.Page_Base import Page_Base
import time


class TodoPage(Page_Base):
    def cond_query(self):
        driver = self.driver
        js = "div=document.getElementById('rightUp');" \
             "a=div.getElementsByTagName('a');" \
             "a[0].click();"
        driver.execute_script(js)
        time.sleep(13)

    def check_query(self):
        try:
            result = self.driver.find_element_by_xpath("html/body/div[2]/div[2]/a[2]").text
            self.assertNotEquals(result, u"暂无数据信息", msg="MSG查询有相应数据")
            if u"待处理事项" == result:
                print ("查询成功，有满足条件的记录")
            else:
                print ("查询失败，无满足条件的记录")
        except BaseException as e:
            print ("查询异常", e)
