# coding: utf-8
from Page_Object.Page_Base import Page_Base
import time


class ElectricStatus(Page_Base):

    def check_query(self, name):
        driver = self.driver
        try:
            result = driver.find_element_by_id(name).text
            time.sleep(3)
            self.assertNotEquals(result, u"暂无数据信息", msg="MSG查询有相应数据")
            if u"暂无数据信息" == result:
                print ("查询失败，无满足条件的记录")
            else:
                print ("查询成功，有满足条件的记录")
        except Exception as e:
            print ('元素定位失败', 2)


