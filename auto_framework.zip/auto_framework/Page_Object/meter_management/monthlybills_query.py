#coding:utf-8


import time,sys
sys.path.append("D:\\auto_framework\\Page_Object")
from Page_Object.Page_Base import Page_Base
from selenium.webdriver.common.by import By
from selenium.webdriver.support.wait import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import Select

class monthlybills_query(Page_Base):

    def cond_query(self):

        passdriver1 = WebDriverWait(self.driver, timeout=10).until(EC.presence_of_element_located((By.ID, "startDate")),
                                                                 message=u'元素加载超时！')
        passdriver1.clear()

        passdriver1.send_keys("2017-09-01")

        passdriver2 = WebDriverWait(self.driver, timeout=10).until(EC.presence_of_element_located((By.ID, "endDate")),
                                                                 message=u'元素加载超时！')
        passdriver2.clear()

        passdriver2.send_keys("2017-10-10")

        self.driver.find_element_by_id('btnQuery').click()

        iSBrand = WebDriverWait(self.driver, timeout=10).until(EC.presence_of_element_located((By.ID, "iSBrand")),
                                                                message=u'元素加载超时！')
        iSBrand.find_elements_by_tag_name("option")[0].click()

        plazaSel = WebDriverWait(self.driver, timeout=10).until(EC.presence_of_element_located((By.ID, "plazaSel")),
                                                               message=u'元素加载超时！')
        plazaSel.find_elements_by_tag_name("option")[11].click()

        KeepPowerType = WebDriverWait(self.driver, timeout=10).until(EC.presence_of_element_located((By.ID, "KeepPowerType")),
                                                                message=u'元素加载超时！')
        KeepPowerType.find_elements_by_tag_name("option")[0].click()

        AccountName = WebDriverWait(self.driver, timeout=10).until(EC.presence_of_element_located((By.ID, "AccountName")),
                                                                   message=u'元素加载超时！')
        AccountName.send_keys("")

        DeviceName = WebDriverWait(self.driver, timeout=10).until(EC.presence_of_element_located((By.ID, "DeviceName")),
                                                                   message=u'元素加载超时！')
        DeviceName.send_keys("")


    def check_result(self):
        try:
            Result = self.driver.find_element_by_xpath(".//*[@id='deviceList']/tbody/tr/td").text

            print "assertNotEquals Start"
            self.assertNotEquals(Result, u"暂无数据信息", msg="MSG查询有相应数据")
            print "assertNotEquals End"

            print "assertEquals Start"
            self.assertEquals(Result, u"暂无数据信息", msg="MSG查询有相应数据")
            print "assertEquals End"


            #print("Result=%s" %Result)
            if (u"暂无数据信息" == Result):
                print ("查询失败，无满足条件的记录")
            else:
                print ("查询成功，有满足条件的记录")

        except:
            print ("查询异常")