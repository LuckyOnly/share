#coding:utf-8


import time,sys
import os
sys.path.append("D:\\auto_framework\\Page_Object")
from Page_Object.Page_Base import Page_Base
from selenium.webdriver.common.by import By
from selenium.webdriver.support.wait import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.by import By
from selenium.webdriver.support.select import Select

class electric_device(Page_Base):

    def getName(self,id):
        '''获取指定的广场对应的id'''
        time.sleep(20)
        js= "var spanList=$('#tree-container li div[id="+id+"] span.tree-title');" \
            "alert(spanList[0]);" \
            " spanList[0].click();"
        self.driver.execute_script(js)
        self.driver.switch_to_alert().accept()

    def cond_query(self):
        self.getName("_easyui_tree_14")
        time.sleep(30)
        #获取广场所有电表信息
        # js1="var treeList=$('#tree-container li div[id=_easyui_tree_14] span.tree-title');alert(treeList[0].innerText);treeList[0].click();"
        # self.driver.execute_script(js1)
        # self.driver.switch_to_alert().accept()

        # device1=WebDriverWait(self.driver,timeout=10  ).until(ec.presence_of_element_located((By.XPATH,"html/body/div[3]/div[1]/div[1]/li[14]/div/span[3]")), message=u'元素加载超时！')
        # print device1.text
        # device1.click()




        # device4 = WebDriverWait(self.driver, timeout=20).until(
        #     ec.presence_of_element_located((By.XPATH, "html/body/div[3]/div[3]/table/tbody/tr[19]/td[11]/span[1]/a")),
        #     message=u'元素加载超时！')
        # print device4.text
        # device4.click()
        # self.driver.find_element_by_id('_easyui_tree_14');
        # js= "var spanList=$('#_easyui_tree_205 span.tree-title');" \
        #     "alert(spanList[0]);" \
        #     "if (spanList[0].innerText==='WS0118')" \
        #     "{    spanList[0].click();}"
        # self.driver.execute_script(js)
        # self.driver.switch_to_alert().accept()
        # self.getName('WS0118')



    def cond_charge(self,name):
        #点击充值按钮
        device5="var tableList=$('#list_device tbody tr td a');" \
                "for(var i=0;i<tableList.length;i++)" \
                "{    if(tableList[i].innerText==='"+name+"')" \
                "{   tableList[i+1].click();  }}"
        self.driver.execute_script(device5)
        time.sleep(5)
        inputList=WebDriverWait(self.driver, timeout=10).until(
                EC.presence_of_element_located((By.ID, "rechargeInput")),
                message=u'元素加载超时！')
        inputList.send_keys('0.01')
        btnList=WebDriverWait(self.driver, timeout=10).until(
                EC.presence_of_element_located((By.ID, "btnRecharge")),
                message=u'元素加载超时！')
        btnList.click()
        time.sleep(5)
        self.driver.switch_to_alert().accept()
        time.sleep(5)
    def check_result(self):
        try:
            # 校验广场名称页面
            time.sleep(10)
            device2 = WebDriverWait(self.driver, timeout=10).until(
                EC.presence_of_element_located((By.ID, "SquareName")),
                message=u'元素加载超时！').text

            self.assertNotEquals(device2, u"暂无数据信息", msg="MSG查询有相应数据")
            if (u"暂无数据信息" == device2):
                print ("操作失败")
            else:
                print ('操作成功')
            # 校验电表信息
            device3 = WebDriverWait(self.driver, timeout=20).until(
                EC.presence_of_element_located((By.XPATH, "html/body/div[3]/div[3]/table/tbody/tr[19]/td[2]/a")),
                message=u'元素加载超时！').text

            self.assertNotEquals(device3, u"暂无数据信息", msg="MSG查询有相应数据")
            if (u"暂无数据信息" == device3):
                print ("操作失败")
            else:
                print ('操作成功')
        except:
            print ("查询异常")
