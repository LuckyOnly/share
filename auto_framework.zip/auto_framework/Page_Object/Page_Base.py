# coding:utf-8
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.by import By
import  time,pymysql

class Page_Base():

    def __init__(self,selenium_driver):
        self.driver=selenium_driver

    def find_element(self,*loc):
        # 加上显式等待
        find_element=WebDriverWait(self.driver,30,1).until(EC.presence_of_element_located(*loc))
        return find_element

    def script(self,src):
        return self.driver.execute_script(src)
    def click_page1(self,module,page):
        driver = self.driver
        jsStr = "var test=document.getElementsByClassName('menuList w_100')[0].firstElementChild;" \
                "var lis=test.getElementsByTagName('li');" \
                "var uls;" \
                "var lisa;" \
                "for(var i=0;i<lis.length;i++){" \
                "    uls=lis[i].getElementsByTagName('ul');" \
                "lisa=lis[i].getElementsByTagName('a')[0].innerText;" \
                "   if(lisa=='" + module + "'){" \
               "alert(lisa);" \
               "       for(var j=0;j<uls.length;j++){" \
               "        twolis=uls[j].getElementsByTagName('li');" \
               "         for(var k=0;k<twolis.length;k++){" \
               "           as=twolis[k].getElementsByTagName('a')[0];" \
               "           if(as.innerText=='" + page + "'){" \
            "               as.click();" \
            "               break;" \
            "           }" \
            "        }" \
            "    }" \
            "    }}"
        driver.execute_script(jsStr)
        t = driver.switch_to_alert()
        print t.text
        t.accept()

    def click_page2(self,module):
        driver = self.driver
        jsStr = "var test=document.getElementsByClassName('menuList w_100')[0].firstElementChild;" \
                "var lis=test.getElementsByTagName('li');" \
                "var uls;" \
                "var lisa;" \
                "for(var i=0;i<lis.length;i++){" \
                "    uls=lis[i].getElementsByTagName('ul');" \
                "lisa=lis[i].getElementsByTagName('a')[0];" \
                "   if(lisa.innerText=='" + module + "'){" \
                                           "alert(lisa);" \
                                           "lisa.click()}}"
        driver.execute_script(jsStr)
        t = driver.switch_to_alert()
        # print t.text
        t.accept()
        # assert  page in driver.title
    def drop_down_list_btn(self):
        '''下拉框'''
        inputContent=self.driver.find_elements_by_xpath('html/body/div[1]/div[3]/div/div/div[1]/div/div/div[1]/a/span[2]/b');

    def click_page(self,module,page):
        # 鼠标移动到主菜单
        #parent_menu=self.find_element((By.XPATH,"//span[text()='{x}']".format(x=module)))
        #ActionChains(self.driver).move_to_element(parent_menu).perform()

        above = self.find_element((By.XPATH, "//a[text()='{x}']".format(x=module)))
        print("above=%s" %above)
        above.click()
        time.sleep(2)

        # above1 = self.find_element((By.XPATH, "//a[text()='{x}']".format(x=page)))
        # print("above1=%s" % above1)
        # above1.click()
        print ("page=%s" %page)
        # above1 = self.find_element((By.XPATH, ".//*[@id='subMenuItemAppended']/li[1]/a"))
        # print("above1=%s" %above1)
        # above1.click()

        if (u"集中器型号" == page):

            above1 = self.find_element((By.XPATH, ".//*[@id='subMenuItemAppended']/li[1]/a"))
            print("above1=%s" % above1.get_attribute('href'))

            above1.click()

        if (u"设备厂家" == page):
            above1 = self.find_element((By.XPATH, ".//*[@id='subMenuItemAppended']/li[4]/a"))
            print("above1=%s" %above1)
            above1.click()

        if (u"设备型号" == page):
            above1 = self.find_element((By.XPATH, ".//*[@id='subMenuItemAppended']/li[2]/a"))
            print("above1=%s" %above1)
            above1.click()

        if (u"设备管理" == page):
            above1 = self.find_element((By.XPATH, ".//*[@id='subMenuItemAppended']/li[2]/a"))
            print("above1=%s" %above1)

            above1.click()

        if (u"集中器设置" == page ):
            above1 = self.find_element((By.XPATH, ".//*[@id='subMenuItemAppended']/li[3]/a"))
            print("above1=%s" % above1)
            above1.click()
        # if ( u"品牌电表"== page):
            # jsStr = "var test=document.getElementsByClassName('menuList w_100')[0].firstElementChild;" \
            #         "console.log(test);" \
            #         "var lis=test.getElementsByTagName('li');" \
            #         "uls=lis[1].getElementsByTagName('ul');" \
            #         "twolis=uls[0].getElementsByTagName('li');" \
            #         "as=twolis[0].getElementsByTagName('a')[0];" \
            #         "if(as.innerText=='"+page+"'){" \
            #         "    as.click();}"

        if (u"操作日志" == page):
            above1 = self.find_element((By.XPATH, ".//*[@id='subMenuItemAppended']/li[1]/a"))
            print("above1=%s" % above1)
            above1.click()

        if (u"仪表状态查询" == page):
            above1 = self.find_element((By.XPATH, ".//*[@id='subMenuItemAppended']/li[4]/a"))
            print("above1=%s" % above1)
            above1.click()

        if (u"费率管理" == page):
            above1 = self.find_element((By.XPATH, ".//*[@id='subMenuItemAppended']/li[3]/a"))
            print("above1=%s" % above1)
            above1.click()

        if (u"角色管理" == page):
            above1 = self.find_element((By.XPATH, ".//*[@id='subMenuItemAppended']/li[1]/a"))
            print("above1=%s" % above1)
            above1.click()

        if (u"用户管理" == page):
            above1 = self.find_element((By.XPATH, ".//*[@id='subMenuItemAppended']/li[3]/a"))
            print("above1=%s" % above1)
            above1.click()

        if (u"账单查询" == page):
            above1 = self.find_element((By.XPATH, ".//*[@id='subMenuItemAppended']/li[6]/a"))
            print("above1=%s" % above1)
            above1.click()

        if (u"月账单查询" == page):
            above1 = self.find_element((By.XPATH, ".//*[@id='subMenuItemAppended']/li[7]/a"))
            print("above1=%s" % above1)
            above1.click()

        # above = self.driver.find_element(By.LINK_TEXT,"基础信息")
        # time.sleep(2)
        # ActionChains(self.driver).move_to_element(above).perform()
        # time.sleep(5)
        # above2 = self.driver.find_elements_by_xpath(".//*[@id='subMenuItemAppended']/li[1]/a")
        # above2.click()


        # above1 = self.driver.find_element_by_link_text("集中器型号")
        # above1.click()

        # left = WebDriverWait(self.driver, 20, 0.5).until(ec.presence_of_element_located((By.LINK_TEXT, page)))
        # time.sleep(2)
        # left.click()

    def login_system(self,user,password):
        self.driver.find_element_by_id('username').send_keys(user)
        self.driver.find_element_by_id('password').send_keys(password)
        self.driver.find_element_by_id("login_button").click()
        time.sleep(2)

    def click_button(self,button):
        self.find_element((By.XPATH,"//a[text()='{s}']".format(s=button))).click()

    def get_element(self, name, args=1):
        # 一级标题栏
        if name == "title":
            element = self.find_element(self.driver, 'xpath',"html/body/section/header/div[3]/ul/li[" + str(args) + "]/a/span[2]")
            return element
        # 二级标题栏
        if name == "title2":
            element = self.find_element(self.driver, 'xpath',
                                   "html/body/section/header/div[3]/ul/li[" + str(args[0]) + "]/div/ul/li[" + str(
                                       args[1]) + "]/a/span")
            return element
        # 查找表格中的元素
        if name == "table":
            element = self.find_element(self.driver, 'xpath',".//*[@id='example']/tbody/tr[" + str(args[0]) + "]/td[" + str(args[1]) + "]")
            return element
        if name == "table_rows":
            elements = self.driver.find_elements_by_xpath(".//*[@id='example']/tbody/tr")
            return elements
        if name == "link_in_table":
            element =self. find_element(self.driver, 'xpath', ".//*[@id='example']/tbody/tr[" + str(args[0]) + "]/td[" + str(
                args[1]) + "]/a[" + str(args[2]) + "]")
            return element
        if name == "checkbox_in_table":
            element = self.find_element(self.driver, 'xpath',
                                   ".//*[@id='example']/tbody/tr[" + str(args[0]) + "]/td[" + str(args[1]) + "]/input")
            return element
        # 查找页面中的a标签，通过对应文字进行查找
        if name == "link":
            element = self.find_element(self.driver, 'link_text', args)
            return element
        # 查找弹出的frame
        if name == "frame":
            element = self.find_element(self.driver, 'tag', "iframe")
            return element
        # 查询按钮，时间框，大部分页面都有
        if name == "startTime":
            element = self.find_element(self.driver, 'id', "startTime")
            return element
        if name == "endTime":
            element = self.find_element(self.driver, 'id', "endTime")
            return element
        if name == "search":
            element = self.find_element(self.driver, 'xpath', ".//*[@id='search']")
            return element
        # 查找弹出的确认框，有两种，一种是有是否选项的，一种是成功确认的，等之后实现吧
        if name == "confirm":
            element = self.find_element(self.driver, 'class', "layui-layer-btn0")
            return element
        return

    def selectTreeArea(self, indexes):
        driver = self.driver
        time.sleep(1)
        path = ".//*[@id='selectArea']/div"
        top = 0  # 距顶部的距离
        driver.execute_script('document.getElementById("selectArea").scrollTop=' + str(top))  # 从顶部开始吧
        while len(indexes) > 0:
            num = indexes.pop()
            if len(indexes) == 0:  # 如果没有了，选择下面的a标签进行点击
                path = path + "/li[" + str(num) + "]/a"
                break
            else:
                flag = False
                while flag == False and top < 2000:
                    try:
                        ifopen = True
                        try:  # 查找一下这个标签是不是已经打开了，如果打开了就不点击了
                            driver.find_element_by_xpath(
                                path + "/li[" + str(num) + "]/span[contains(@class, 'noline_open')]")
                        except:
                            ifopen = False
                        if ifopen == False:
                            driver.find_element_by_xpath(path + "/li[" + str(num) + "]/span").click()  # 点击标签展开选项

                        flag = True  # 如果执行成功，跳出循环
                    except:
                        top = top + 100
                        driver.execute_script('document.getElementById("selectArea").scrollTop=' + str(top))  # 慢慢的往下拖
                        time.sleep(1)

                if flag == False:
                    print("cannot locate the element:" + path)
                    raise AssertionError

                time.sleep(2)  # 这里选项是点开了才会加载
                path = path + "/li[" + str(num) + "]/ul"  # 将path指向下一层的列表

        driver.find_element_by_xpath(path).click()
        return

    def execSql(self, sql):
        conn = pymysql.connect(host='192.168.20.74',
                               port=3306,
                               user='eway',
                               passwd='iamnts',
                               db="ewayecm_plat6")
        cur = conn.cursor()
        cur.execute(sql)
        conn.commit()
        cur.close()
        conn.close()
        return

    def execSql2(self, sql):
        conn = pymysql.connect(host='192.168.20.74',
                               port=3306,
                               user='eway',
                               passwd='iamnts',
                               db="eway_plat6")
        cur = conn.cursor()
        cur.execute(sql)
        conn.commit()
        cur.close()
        conn.close()
        return

# def find_element(driver, mode, content):
#     locate_flag = 0
#     sleep_time = 0.2
#     num = 0
#     TIMEOUT = 20
#     if mode == 'xpath':
#         while (locate_flag == 0 | num < TIMEOUT):
#             try:
#                 el = WebDriverWait(driver, 10, 0.5).until(
#                     ec.presence_of_element_located((By.XPATH, content)))
#             except:
#                 time.sleep(1)
#                 num += 1
#                 print 'repeat locate ' + str(num)
#             else:
#                 locate_flag = 1
#         if (num > TIMEOUT - 1):
#             print 'quit locate because timeout'
#         time.sleep(sleep_time)
#         return WebDriverWait(driver, 10, 0.5).until(
#             ec.presence_of_element_located((By.XPATH, content)))
#
#     elif mode == 'id':
#         while (locate_flag == 0 | num < TIMEOUT):
#             try:
#                 el = WebDriverWait(driver, 10, 0.5).until(
#                     ec.presence_of_element_located((By.ID, content)))
#             except:
#                 time.sleep(1)
#                 num += 1
#                 print 'repeat locate ' + str(num)
#             else:
#                 locate_flag = 1
#         if (num > TIMEOUT - 1):
#             print 'quit locate because timeout'
#         time.sleep(sleep_time)
#         return WebDriverWait(driver, 10, 0.5).until(ec.presence_of_element_located((By.ID, content)))
#     elif mode == 'class':
#         while (locate_flag == 0 | num < TIMEOUT):
#             try:
#                 el = WebDriverWait(driver, 10, 0.5).until(
#                     ec.presence_of_element_located((By.CLASS_NAME, content)))
#             except:
#                 time.sleep(1)
#                 num += 1
#                 print 'repeat locate ' + str(num)
#             else:
#                 locate_flag = 1
#         if (num > TIMEOUT - 1):
#             print 'quit locate because timeout'
#         time.sleep(sleep_time)
#         return WebDriverWait(driver, 10, 0.5).until(
#             ec.presence_of_element_located((By.CLASS_NAME, content)))
#
#     elif mode == 'tag':
#         while (locate_flag == 0 | num < TIMEOUT):
#             try:
#                 el = WebDriverWait(driver, 10, 0.5).until(
#                     ec.presence_of_element_located((By.TAG_NAME, content)))
#             except:
#                 time.sleep(1)
#                 num += 1
#                 print 'repeat locate ' + str(num)
#             else:
#                 locate_flag = 1
#         if (num > TIMEOUT - 1):
#             print 'quit locate because timeout'
#         time.sleep(sleep_time)
#         return WebDriverWait(driver, 10, 0.5).until(
#             ec.presence_of_element_located((By.TAG_NAME, content)))
#
#     elif mode == 'link_text':
#         while (locate_flag == 0 | num < TIMEOUT):
#             try:
#                 el = WebDriverWait(driver, 10, 0.5).until(
#                     ec.presence_of_element_located((By.LINK_TEXT, content)))
#             except:
#                 time.sleep(1)
#                 num += 1
#                 print 'repeat locate ' + str(num)
#             else:
#                 locate_flag = 1
#         if (num > TIMEOUT - 1):
#             print 'quit locate because timeout'
#         time.sleep(sleep_time)
#         return WebDriverWait(driver, 10, 0.5).until(
#             ec.presence_of_element_located((By.LINK_TEXT, content)))
#     else:
#         print 'please enter right locate mode'