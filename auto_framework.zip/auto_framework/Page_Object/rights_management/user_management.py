#coding:utf-8


import time,sys
sys.path.append("D:\\auto_framework\\Page_Object")
from Page_Object.Page_Base import Page_Base
from selenium.webdriver.common.by import By
from selenium.webdriver.support.wait import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import Select

class user_management(Page_Base):

    def cond_query(self):

        search_input = WebDriverWait(self.driver, timeout=10).until(EC.presence_of_element_located((By.CLASS_NAME, "search_input")),
                                                                 message=u'元素加载超时！')
        search_input.send_keys("yitao")

        OtherName = WebDriverWait(self.driver, timeout=10).until(EC.presence_of_element_located((By.ID, "OtherName")),
                                                                 message=u'元素加载超时！')
        OtherName.send_keys(u"易涛")

        # uGroups = WebDriverWait(self.driver, timeout=10).until(ec.presence_of_element_located((By.ID, "uGroups")),
        #                                                           message=u'元素加载超时！')
        # uGroups.find_elements_by_tag_name("option")[3].click()

        # statusGroup = WebDriverWait(self.driver, timeout=10).until(ec.presence_of_element_located((By.ID, "statusGroup")),
        #                                                        message=u'元素加载超时！')
        # statusGroup.find_elements_by_tag_name("option")[1].click()
        #
        # selPlaza = WebDriverWait(self.driver, timeout=10).until(ec.presence_of_element_located((By.ID, "selPlaza")),
        #                                                        message=u'元素加载超时！')
        # selPlaza.find_elements_by_tag_name("option")[50].click()

        self.driver.find_element_by_id('search-btn').click()
        time.sleep(2)

    def check_result(self):
        try:
            Result = self.driver.find_element_by_xpath("//*[@id='dataList']/tr/td").text
            self.assertNotEquals(Result, u"暂无数据信息", msg="MSG查询有相应数据")
            #print("Result=%s" %Result)
            if u"暂无数据信息" == Result:
                print ("查询失败，无满足条件的记录")
            else:
                print ("查询成功，有满足条件的记录")

        except:
            print ("查询异常")