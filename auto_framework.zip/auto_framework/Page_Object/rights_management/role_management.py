#coding:utf-8


import time,sys
sys.path.append("D:\\auto_framework\\Page_Object")
from Page_Object.Page_Base import Page_Base
from selenium.webdriver.common.by import By
from selenium.webdriver.support.wait import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import Select

class role_management(Page_Base):

    def cond_query(self):

        roleLevel = WebDriverWait(self.driver, timeout=10).until(EC.presence_of_element_located((By.ID, "roleLevel")),
                                                                 message=u'元素加载超时！')
        roleLevel.find_elements_by_tag_name("option")[1].click()
        time.sleep(2)

        roleName = WebDriverWait(self.driver, timeout=10).until(EC.presence_of_element_located((By.ID, "roleName")),
                                                                  message=u'元素加载超时！')
        roleName.find_elements_by_tag_name("option")[0].click()
        time.sleep(2)

        self.driver.find_element_by_id('search-btn').click()


    def check_result(self):
        try:
            Result = self.driver.find_element_by_xpath("//*[@id='dataList']/tr/td").text
            self.assertNotEquals(Result, u"暂无数据信息", msg="MSG查询有相应数据")
            #print("Result=%s" %Result)
            if (u"暂无数据信息" == Result):
                print ("查询失败，无满足条件的记录")
            else:
                print ("查询成功，有满足条件的记录")

        except:
            print ("查询异常")