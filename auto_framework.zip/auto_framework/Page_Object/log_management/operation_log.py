#coding:utf-8


import time,sys
sys.path.append("D:\\auto_framework\\Page_Object")
from Page_Object.Page_Base import Page_Base
from selenium.webdriver.common.by import By
from selenium.webdriver.support.wait import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import Select

class operation_log(Page_Base):

    def cond_query(self):

        # PlazaName = WebDriverWait(self.driver, timeout=10).until(ec.presence_of_element_located((By.ID, "sltPlaza")),
        #                                                          message=u'元素加载超时！')
        #PlazaName.find_elements_by_tag_name("option")[11].click()
        #self.driver.find_element_by_xpath("//div[text()='长春红旗街万达广场']").click()

        #PlazaName.select_by_visible_text("长春红旗街万达广场")

        # select = Select(self.driver.find_element_by_tag_name("select"))  # 直接套用不需要修改
        # select.select_by_visible_text("长春红旗街万达广场")  # 通过显示的文字来选择




        self.driver.find_element_by_xpath("html/body/div[3]/div/div[3]/div[2]/input[3]").send_keys("admin")
        time.sleep(4)

        passdriver1 = WebDriverWait(self.driver, timeout=10).until(EC.presence_of_element_located((By.NAME, "startDate")),
                                                                 message=u'元素加载超时！')
        passdriver1.clear()
        time.sleep(4)
        passdriver1.send_keys("2017-09-01")

        passdriver2 = WebDriverWait(self.driver, timeout=10).until(EC.presence_of_element_located((By.NAME, "endDate")),
                                                                 message=u'元素加载超时！')
        passdriver2.clear()
        time.sleep(4)
        passdriver2.send_keys("2017-09-25")

        """广场名称"""
        PlazaList = WebDriverWait(self.driver, timeout=10).until(EC.presence_of_element_located((By.ID, "plazaList")),
                                                                message=u'元素加载超时！')
        PlazaList.find_elements_by_tag_name("option")[11].click()
        time.sleep(4)

        """类型"""
        ExistType = WebDriverWait(self.driver, timeout=10).until(EC.presence_of_element_located((By.ID, "ExistType")),
                                                                 message=u'元素加载超时！')
        ExistType.find_elements_by_tag_name("option")[1].click()
        time.sleep(10)

        BrandList = WebDriverWait(self.driver, timeout=10).until(EC.presence_of_element_located((By.ID, "brandlist")),
                                                                 message=u'元素加载超时！')
        BrandList.find_elements_by_tag_name("option")[0].click()
        time.sleep(6)
        """电表名称"""
        DeviceList = WebDriverWait(self.driver, timeout=10).until(EC.presence_of_element_located((By.ID, "devicelist")),
                                                                 message=u'元素加载超时！')
        DeviceList.find_elements_by_tag_name("option")[0].click()
        time.sleep(4)

        OperList = WebDriverWait(self.driver, timeout=10).until(EC.presence_of_element_located((By.ID, "operlist")),
                                                                  message=u'元素加载超时！')
        OperList.find_elements_by_tag_name("option")[0].click()
        time.sleep(4)



        # driver.find_element_by_id("plazaList").find_elements_by_tag_name("option")[11].click()
        # time.sleep(2)
        # driver.find_element_by_id("ExistType").find_elements_by_tag_name("option")[1].click()
        # time.sleep(5)
        # driver.find_element_by_id("brandlist").find_elements_by_tag_name("option")[2].click()
        # time.sleep(2)
        # driver.find_element_by_id("devicelist").find_elements_by_tag_name("option")[1].click()
        # time.sleep(2)
        # driver.find_element_by_id("operlist").find_elements_by_tag_name("option")[0].click()



    def check_result(self):
        try:
            Result = self.driver.find_element_by_xpath("html/body/div[3]/div/div[4]/table/tbody/tr/td").text
            self.assertNotEquals(Result, u"暂无数据信息", msg="MSG查询有相应数据")
            #print("Result=%s" %Result)
            if (u"暂无数据信息" == Result):
                print ("查询失败，无满足条件的记录")
            else:
                print ("查询成功，有满足条件的记录")

        except:
            print ("查询异常")