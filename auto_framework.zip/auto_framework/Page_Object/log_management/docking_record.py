# coding: utf-8

import time
from Page_Object.Page_Base import Page_Base
from selenium.webdriver.support.wait import WebDriverWait
from selenium.webdriver.support import expected_conditions as ec
from selenium.webdriver.common.by import By


class DockingRecord(Page_Base):
    def cond_reset(self):
        start_time = WebDriverWait(self.driver, timeout=10).until(
            ec.presence_of_element_located((By.XPATH, "html/body/div[3]/div[1]/div/input[1]")),
            message=u'元素加载超时！')
        start_time.clear()
        time.sleep(4)
        start_time.send_keys("2018-01-26")
        time.sleep(4)

        end_time = WebDriverWait(self.driver, timeout=10).until(
            ec.presence_of_element_located((By.XPATH, "html/body/div[3]/div[1]/div/input[2]")),
            message=u'元素加载超时！')

        end_time.clear()
        time.sleep(4)
        end_time.send_keys("2018-01-31")
        time.sleep(4)

        """发送状态"""
        send_state = WebDriverWait(self.driver, timeout=10).until(ec.presence_of_element_located((By.ID, "SendeState")),
                                                                  message=u'元素加载超时！')
        send_state.find_elements_by_tag_name("option")[2].click()
        time.sleep(10)

        """接收状态"""
        receive_state = WebDriverWait(self.driver, timeout=10).until(
            ec.presence_of_element_located((By.ID, "ReceiveState")),
            message=u'元素加载超时！')
        receive_state.find_elements_by_tag_name("option")[0].click()
        time.sleep(6)
        """信息类型"""
        message_type = WebDriverWait(self.driver, timeout=10).until(
            ec.presence_of_element_located((By.ID, "MessageType")),
            message=u'元素加载超时！')
        message_type.find_elements_by_tag_name("option")[1].click()
        time.sleep(4)
        """接收方"""
        receiver = WebDriverWait(self.driver, timeout=10).until(ec.presence_of_element_located((By.ID, "Receiver")),
                                                                message=u'元素加载超时！')
        receiver.find_elements_by_tag_name("option")[3].click()
        time.sleep(4)

        self.driver.find_element_by_id('ResetBtn').click()
        time.sleep(4)

    def cond_query(self):
        start_time = WebDriverWait(self.driver, timeout=10).until(
            ec.presence_of_element_located((By.XPATH, "html/body/div[3]/div[1]/div/input[1]")),
            message=u'元素加载超时！')
        start_time.clear()
        time.sleep(4)
        start_time.send_keys("2018-01-26")
        time.sleep(4)

        end_time = WebDriverWait(self.driver, timeout=10).until(
            ec.presence_of_element_located((By.XPATH, "html/body/div[3]/div[1]/div/input[2]")),
            message=u'元素加载超时！')

        end_time.clear()
        time.sleep(4)
        end_time.send_keys("2018-01-31")
        time.sleep(4)

        """发送状态"""
        send_state = WebDriverWait(self.driver, timeout=10).until(ec.presence_of_element_located((By.ID, "SendeState")),
                                                                  message=u'元素加载超时！')
        send_state.find_elements_by_tag_name("option")[2].click()
        time.sleep(10)

        """接收状态"""
        receive_state = WebDriverWait(self.driver, timeout=10).until(
            ec.presence_of_element_located((By.ID, "ReceiveState")),
            message=u'元素加载超时！')
        receive_state.find_elements_by_tag_name("option")[0].click()
        time.sleep(6)
        """信息类型"""
        message_type = WebDriverWait(self.driver, timeout=10).until(
            ec.presence_of_element_located((By.ID, "MessageType")),
            message=u'元素加载超时！')
        message_type.find_elements_by_tag_name("option")[1].click()
        time.sleep(4)
        """接收方"""
        receiver = WebDriverWait(self.driver, timeout=10).until(ec.presence_of_element_located((By.ID, "Receiver")),
                                                                message=u'元素加载超时！')
        receiver.find_elements_by_tag_name("option")[3].click()
        time.sleep(4)

        self.driver.find_element_by_id('SearchBtn').click()
        time.sleep(4)

    def check_reset(self):
        try:
            start_time = WebDriverWait(self.driver, timeout=10).until(
                ec.presence_of_element_located((By.XPATH, "html/body/div[3]/div[1]/div/input[1]")),
                message=u'元素加载超时！')
            today_time = time.strftime('%Y-%m-%d',time.localtime(time.time()))
            assert today_time in start_time.get_attribute("value")
            end_time = WebDriverWait(self.driver, timeout=10).until(
                ec.presence_of_element_located((By.XPATH, "html/body/div[3]/div[1]/div/input[2]")),
                message=u'元素加载超时！')
            assert today_time in end_time.get_attribute("value")
            """发送状态"""
            send_state = WebDriverWait(self.driver, timeout=10).until(ec.presence_of_element_located((By.ID, "SendeState")),
                                                                      message=u'元素加载超时！')
            time.sleep(3)
            assert u"全部" in send_state.text

            """接收状态"""
            receive_state = WebDriverWait(self.driver, timeout=10).until(
                ec.presence_of_element_located((By.ID, "ReceiveState")),
                message=u'元素加载超时！')
            time.sleep(3)
            assert u"全部" in receive_state.text
            """信息类型"""
            message_type = WebDriverWait(self.driver, timeout=10).until(
                ec.presence_of_element_located((By.ID, "MessageType")),
                message=u'元素加载超时！')
            time.sleep(3)
            assert u"全部" in message_type.text

            """接收方"""
            receiver = WebDriverWait(self.driver, timeout=10).until(ec.presence_of_element_located((By.ID, "Receiver")),
                                                                    message=u'元素加载超时！')
            time.sleep(3)
            assert u"全部" in receiver.text
        except Exception as e:
            print ("查询异常",e)

    def check_result(self):
        try:
            result = self.driver.find_element_by_xpath("html/body/div[3]/div[2]/div[2]/table/tbody/tr[1]/td[2]").text
            self.assertNotEqual(result, u"暂无数据信息", msg="MSG查询有相应数据")
            if u"暂无数据信息" == result:
                print ("查询失败，无满足条件的记录")
            else:
                print ("查询成功，有满足条件的记录")
        except Exception as e:
            print ("查询异常",e)
