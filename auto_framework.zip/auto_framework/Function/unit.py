#coding:utf-8

from selenium import  webdriver
from selenium.webdriver.support.wait import WebDriverWait
import unittest
import time
import sys
import pymysql
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.by import By
# from filelock import FileLock
from selenium import webdriver
from selenium.webdriver.common.desired_capabilities import DesiredCapabilities


class unit(unittest.TestCase):

    #定义类变量，用于类方法
    # url='http://192.168.20.28:7800/employeelogin.html'
    url='http://192.168.50.80:7800/employeelogin.html'
    # 必须绝对路径，因为实际执行在case里
    filename='D:\\auto_framework\\Function\\account'
    line=None
    driver=None

    # 每个测试类的开始与结束时被执行
    @classmethod
    def setUpClass(cls):
        # cls.driver = webdriver.Remote(
        #     # command_executor='http://192.168.40.170:8888/wd/hub',
        #     command_executor='http://192.168.50.83:8802/wd/hub',
        #
        #     desired_capabilities=DesiredCapabilities.FIREFOX
        #
        # )
        cls.driver = webdriver.Firefox()
        cls.driver.get(cls.url)
        time.sleep(2)
        print "open browser success"
        cls.driver.maximize_window()

        # cls.driver.maximize_window()   # selenium3.0，报错
        #driver.implicitly_wait(10)

        # account = cls.getAccount(cls.filename)
        # cls.loginsystem(account)

        # webdriver1 = cls.driver.Web
        # time.sleep(1)
        # webdriver1.send_keys("admin")
        # webdriver2 = cls.driver.find_element_by_id('password')
        # time.sleep(1)
        # webdriver2.send_keys("1")
        # time.sleep(1)
        # webdriver3 = cls.driver.find_element_by_id("login_button")
        # time.sleep(1)
        # webdriver3.click()

        email = WebDriverWait(cls.driver, timeout=10).until(EC.presence_of_element_located((By.ID, "username")),
                                                        message=u'元素加载超时！')
        email.send_keys("admin")
        passdriver = WebDriverWait(cls.driver, timeout=10).until(EC.presence_of_element_located((By.ID, 'password')),
                                                             message=u'元素加载超时！')
        passdriver.send_keys("1")
        cls.driver.find_element_by_id("login_button").click()
        #cls.conn = pymysql.connect(host='10.2.8.142', user='root', password='root', database='atmv', port=3306,charset='utf8')
        #cls.cu =cls.conn.cursor()
        #print ("connect database ")
        time.sleep(2)
        # assert u'首页' in cls.driver.title
        print u"Home page is loaded"

    @classmethod
    def tearDownClass(cls):
        # print ("tearDownClass")
        time.sleep(2)
        cls.driver.quit()
        # cls.rerurnAccount(cls.filename)
        print "close browser success"
        #cls.cu.close()
        #cls.conn.close()
        #print ("exit databse ")

    # @classmethod
    # def loginsystem(cls, account):
    #     print ("loginsystem1")
    #     cls.driver.find_element_by_id('username').send_keys(account[0])
    #     print ("loginsystem2")
    #     cls.driver.find_element_by_id('password').send_keys(account[1])
    #     print ("loginsystem3")
    #     cls.driver.find_element_by_xpath("//input[@value='登录']").click()
    #     print ("loginsystem4")
    #
    #     try:  # 强制登录处理
    #         el = cls.driver.find_element_by_class_name("f16")
    #         if el.is_displayed():
    #             el.click()
    #             print "force login"
    #         else:
    #             pass
    #     except:
    #         pass
    #     time.sleep(2)
    #
    # #获取账号密码
    # @classmethod
    # def getAccount(cls,file):
    #     with FileLock(file):
    #         print ("getAccount")
    #         fr=open(file)
    #         cls.line=fr.readline() #读取第一行,设为类属性
    #         lines= fr.readlines() #读取第二行后所有的
    #         account=cls.line.split(',')
    #         fr.close()
    #         fw= open(file, 'w')# 重写文件
    #         b = ''.join(lines)
    #         fw.write(b)
    #         fw.close()
    #         return account
    #
    # #返回账户密码
    # @classmethod
    # def rerurnAccount(cls,file):
    #     with FileLock(file):
    #         print ("rerurnAccount")
    #         f = open(file, 'a')
    #         f.writelines(cls.line)
    #         f.close()












