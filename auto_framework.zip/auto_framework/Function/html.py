#coding:utf8
from  bs4 import  BeautifulSoup

# 将每个用例的名称、测试结果解析出来
soup=BeautifulSoup(open('eway_report.html'),"html.parser")
success_rows=soup.find_all('tr',class_='hiddenRow') # class是关键字 class后加 _
error_rows=soup.find_all('tr',attrs={'class':'none'})
print success_rows
print error_rows
success_list=[]
error_list=[]
for row in success_rows:
    name=row.find('div',class_="testcase").string
    success_list.append(name)
print success_list

for row in error_rows:
    name = row.find('div', class_="testcase").string
    error_list.append(name)
print error_list



#print soup.prettify()
# s=soup.find_all('tr')[-1]
# print soup.find_all('tr')[-1]
# print type(soup.find_all('tr')[-1])
# print s.contents
# for child in s.children:
#     print  child
#
# print soup.find_all(id="total_row")
#
# for child in s.stripped_strings:
#     print  child




