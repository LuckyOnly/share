#-*- coding: UTF-8 -*-'
import os
from bs4 import BeautifulSoup
import time


def getFileList(dir):
    filelist = []

    for s in os.listdir(dir):
        filelist.append(s)  # 获取文件列表
    return filelist

def generate_report():
    htmlFile = open("demo.html", 'r')
    content = htmlFile.read()
    htmlFile.close()
    reports = BeautifulSoup(content, 'html.parser', from_encoding='utf-8')
    result_table = reports.find('table', id='result_table')

    filelist = getFileList("D:\\auto_framework\\report\\report")  # 获取文件列表
    row_counter = 0
    total=[0,0,0,0]

    for file in filelist:
        f = open("../report/" + file, 'r')  # 读取文件内容
        content = f.read()
        report = BeautifulSoup(content, 'html.parser', from_encoding='utf-8')
        f.close()
        #######################################################
        total_row = report.find('tr', id='total_row')
        list=[]
        for child in total_row.stripped_strings:
            if child <> 'Total':
                child=int(child)
                list.append(child)
        total=map(lambda x,y:x+y,list,total)
        ##########################################################
        result = report.find('table', id='result_table')
        rows = result.find_all('tr')
        for row in rows:
            if not row.has_attr('class'):
                continue
            if row['class'] == ['passClass']:
                x = row.find_all('td')[5].a['href']
                count = x[-2:-1]  # 倒数第二个字符是该方法的数量参数
                row.find_all('td')[5].a['href'] = "javascript:showClassDetail('c" + str(row_counter) + "'," + count + ")"  # 修改detail的响应id
                row_counter += 1
            if row['class'] == ['errorClass']:
                x = row.find_all('td')[5].a['href']
                count = x[-2:-1]  # 倒数第二个字符是该方法的数量参数
                row.find_all('td')[5].a['href'] = "javascript:showClassDetail('c" + str(row_counter) + "'," + count + ")"  # 修改detail的响应id
                row_counter += 1
            if row['class'] == ['hiddenRow']:  # 如果是隐藏行，通过detail链接打开，那么就需要自己放进去
                id = row['id']
                row['id'] = 'pt' + str(row_counter - 1) + id[-2:]  # 取子字符串，只是替换了第一个数字编号
                if row.find('div', class_='popup_window') is not None:
                    id = row.find('div', class_='popup_window')['id']
                    row.find('div', class_='popup_window')['id'] = 'div_pt' + str(row_counter - 1) + id[-2:]
                    href = row.a['href']
                    row.a['href'] = "javascript:showTestDetail('div_pt" + str(row_counter - 1) + href[-4:]
                    href = row.find('div', class_='popup_window').a['onclick']
                    row.find('div', class_='popup_window').a['onclick'] = "document.getElementById('div_pt" + str(row_counter - 1) + href[-28:]
            if row['class'] == ['none']:
                id = row['id']
                row['id'] = 'ft' + str(row_counter - 1) + id[-2:]  # 取子字符串，只是替换了第一个数字编号
                id = row.find('div', class_='popup_window')['id']
                row.find('div', class_='popup_window')['id'] = 'div_ft' + str(row_counter - 1) + id[-2:]
                href = row.a['href']
                row.a['href'] = "javascript:showTestDetail('div_ft" + str(row_counter - 1) + href[-4:]
                href = row.find('div', class_='popup_window').a['onclick']
                row.find('div', class_='popup_window').a['onclick'] = "document.getElementById('div_ft" + str(row_counter - 1) + href[-28:]
            result_table.append(row)
    now = time.strftime("%Y-%m-%d", time.localtime(time.time()))
    reports.find("h1").string = u"卫计委项目测试报告-" + now
    #####################################################################
    srcipt_list=['var node=document.getElementById("total_row");',
    'var childList = node.childNodes;',
    'list',
    'childList[3].innerHTML=list[0];',
    'childList[5].innerHTML=list[1];',
    'childList[7].innerHTML=list[2];',
    'childList[9].innerHTML=list[3];']
    st='list=[%d,%d,%d,%d];'%(total[0],total[1],total[2],total[3])
    srcipt_list[2]=st
    total_row=reports.find_all('script')[-1]
    for script in srcipt_list:
        total_row.append(script)
    ######################################################################
    file = open('report.html', 'w')
    file.write(str(reports))

generate_report()