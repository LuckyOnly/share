# coding:utf-8
import time
import os
import sys
from selenium.common import exceptions
import traceback



def write_log(info):
    file_path = os.path.abspath(os.path.dirname(__file__))
    log_file_path = os.path.join(os.path.dirname(file_path), 'Log',
                                 '{x}.log'.format(x=time.strftime(r'%Y-%m-%d', time.localtime())))
    exec_time = time.strftime('%Y-%m-%d %H:%M:%S', time.localtime())
    open(log_file_path, 'a').write(exec_time + ' ' + info + '\n')


def log(func):
    def wrapper(*args, **kwargs):
        try:
            func(*args, **kwargs)
        except exceptions.WebDriverException, e:
            # print  sys.exc_info()
            # logging.error("【Catch Exception】" + traceback.format_exc()+str(e))
            info = 'Exception in ' + func.__name__ + ' method: ' + str(e) + traceback.format_exc()
            write_log(info)
            # 用例被装饰后，必须raise抛出异常，否则程序无法判断用例是否执行失败！！
            raise sys.exc_info()[0]
        else:
            write_log('No exception in %s method.' % func.__name__)

    return wrapper
