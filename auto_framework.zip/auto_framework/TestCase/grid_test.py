# coding:utf-8

from selenium import webdriver
from selenium.webdriver.common.desired_capabilities import DesiredCapabilities

driver = webdriver.Remote(
    command_executor='http://192.168.40.170:8888/wd/hub',
    desired_capabilities=DesiredCapabilities.FIREFOX

)
driver.get("http://192.168.50.80:7800/employeelogin.html")
# driver.quit()