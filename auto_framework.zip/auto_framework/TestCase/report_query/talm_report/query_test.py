# coding: utf-8

import time
import sys
import unittest
from Page_Object.report_query.taml_report import query
from Function import unit
from Function.Logging import write_log
directory = sys.path[1]


class QueryTest(unit.unit, query):

    def setUp(self):
        self.click_page1("报表查询", "商管电表报表")

    def tearDown(self):
        test_method_name = self._testMethodName
        if sys.exc_info()[0]:
            self.driver.save_screenshot(r"%s\ScreenShots\%s_%s.png" % (
                directory, time.strftime(r'%Y-%m-%d-%H%M%S', time.localtime()), test_method_name))
        else:
            write_log('No exception in %s method.' % test_method_name)

    def test_concentrator_query(self):
        time.sleep(6)
        self.cond_query()
        self.check_result()

if __name__ == '__main__':
    unittest.main()

