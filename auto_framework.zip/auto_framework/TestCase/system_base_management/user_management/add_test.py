#coding:utf-8

import time,sys,unittest,pymysql
sys.path.append("D:\\auto_framework\\")

from Page_Object.system_base_management.user_management import user_management
from Function import unit,Logging
from selenium.webdriver.common.by import By
from selenium.webdriver.support import  expected_conditions as EC


'''
# 类执行前被执行
def setUpModule():
    global conn, cu
    conn=pymysql.connect(host='127.0.0.1',user='root',password='123456',port=3306,database='test',charset='utf8')
    cu=conn.cursor()
    print ("connect database ")

def tearDownModule():
    cu.close()
    conn.close()
    print ("exit databse ")
'''

class loginTest(unit.unit,user_management): #多继承，直接使用user_management和Page_Base类中所有方法

    def setUp(self):
        self.driver.refresh()
        self.click_page("系统基础管理", "用户管理")

    def tearDown(self):
        if sys.exc_info()[0]:
            test_method_name = self._testMethodName
            self.driver.save_screenshot("D:\\auto_framework\\ScreenShots\\%s_%s.png" % (test_method_name,time.strftime(r'%Y-%m-%d-%H%M%S', time.localtime())))

    @Logging.log
    def test_001_normal_login(self):
        #self.click_page("系统基础管理", "用户管理")
        self.find_element((By.ID,'accountName')).send_keys('dzy')
        self.click_button('查询')
        time.sleep(2)
        # cu.execute("update test_data set http_method='POST' where case_id=1")
        # conn.commit()

    @Logging.log
    def test_002(self):
        #self.click_button('恢复默认')
        self.find_element((By.ID,'accountName')).send_keys('tessss')
        self.click_button('查询')
        time.sleep(2)



'''

    def test_login2(self):
        login(self.driver).user_login(username='user_no_exist', password='adminadmin')
        self.assertEqual(login(self.driver).login_error_hint(),u'输入的用户名user_no_exist不存在,请重新输入')
        print ("login error")
'''
if __name__=='__main__':
    unittest.main()
