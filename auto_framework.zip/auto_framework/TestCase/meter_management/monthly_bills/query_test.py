# coding: utf-8

import time
import sys
import unittest
from Page_Object.meter_management.monthlybills_query import monthlybills_query
from Function import unit
from Function.Logging import write_log
directory = sys.path[1]


class BillingQuery(unit.unit,monthlybills_query):

    def setUp(self):
        print ("1")
        self.click_page1("电表管理","月账单查询")

    def tearDown(self):
        test_method_name = self._testMethodName
        if sys.exc_info()[0]:
            self.driver.save_screenshot(r"%s\ScreenShots\%s_%s.png" % (
                directory, time.strftime(r'%Y-%m-%d-%H%M%S', time.localtime()), test_method_name))
        else:
            write_log('No exception in %s method.' % test_method_name)

    def test_monthlybillsquery_query(self):
        print ("3")
        time.sleep(1)
        self.cond_query()
        self.check_result()

if __name__ == '__main__':
    unittest.main()

