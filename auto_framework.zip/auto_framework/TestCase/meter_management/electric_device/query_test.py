# coding: utf-8

import time
import sys
import unittest
from Page_Object.meter_management.electric_device import electric_device
from Function import unit
from Function.Logging import write_log
directory = sys.path[1]


class DeviceQuery(unit.unit, electric_device):

    def setUp(self):
        self.click_page1("电表管理", "商管电表")

    def tearDown(self):
        test_method_name = self._testMethodName
        if sys.exc_info()[0]:
            self.driver.save_screenshot(r"%s\ScreenShots\%s_%s.png" % (
                directory, time.strftime(r'%Y-%m-%d-%H%M%S', time.localtime()), test_method_name))
        else:
            write_log('No exception in %s method.' % test_method_name)

    def test_device_query(self):
        print ("充值业务")
        time.sleep(3)
        # self.cond_query()
        # self.check_result()
        # time.sleep(3)
        # self.cond_charge('WS0118')

if __name__ == '__main__':
    unittest.main()

