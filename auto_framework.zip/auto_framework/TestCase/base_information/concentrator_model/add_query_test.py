# coding=utf-8

import time
import sys
import unittest
from Function.Logging import write_log
from Page_Object.base_information.concentrator_model import ConcentratorModel
from Function import unit

directory = sys.path[1]


class ConcentratorQuery(unit.unit, ConcentratorModel):
    def setUp(self):
        self.click_page1("基础信息", "集中器型号")
        self.delete_by_code_name('zongff-1234')
        self.add_concentrator('zongff-1234')

    def tearDown(self):
        self.delete_by_code_name('zongff-1234')
        test_method_name = self._testMethodName
        if sys.exc_info()[0]:
            self.driver.save_screenshot(r"%s\ScreenShots\%s_%s.png" % (
                directory, time.strftime(r'%Y-%m-%d-%H%M%S', time.localtime()), test_method_name))
        else:
            write_log('No exception in %s method.' % test_method_name)

    def test03_add(self):
        # 添加集中器编号为name
        # self.add_concentrator('zongff-1234')
        self.check_result_by_name("zongff-1234")

    def qadd_duplicate_04_test(self):
        # 添加同一个集中器编号为name
        self.add_concentrator('zongff-1234')
        self.check_result_by_name("zongff-1234")

    def test05_modify_code_name(self):
        # 修改通道数
        modify_name = '通道数'
        code_name = 'zongff-1234'
        count = '4'
        self.modify_code_name(modify_name, code_name, count)
        self.check_result_by_type(modify_name, code_name, count)

    def test06_modify_normal_type(self):
        # 修改规范类型
        modify_name = '规范类型'
        name_a = 'zongff-1234'
        name_b = '商业'
        self.modify_code_name(modify_name, name_a, name_b)
        self.check_result_by_type(modify_name, name_a, name_b)

    def test07_modify_type_factory(self):
        # 修改设备厂家
        modify_name = '设备厂家'
        name_a = 'zongff-1234'
        name_b = '深圳科陆'
        self.modify_code_name(modify_name, name_a, name_b)
        self.check_result_by_type(modify_name, name_a, name_b)


if __name__ == '__main__':
    unittest.main()

