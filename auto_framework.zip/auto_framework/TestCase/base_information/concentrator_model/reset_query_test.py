# coding=utf-8

import time
import sys
import unittest
from Function.Logging import write_log
from Page_Object.base_information.concentrator_model import ConcentratorModel
from Function import unit

directory = sys.path[1]


class ConcentratorQuery(unit.unit, ConcentratorModel):
    def setUp(self):
        self.click_page1("基础信息", "集中器型号")

    def tearDown(self):
        test_method_name = self._testMethodName
        if sys.exc_info()[0]:
            self.driver.save_screenshot(r"%s\ScreenShots\%s_%s.png" % (
                directory, time.strftime(r'%Y-%m-%d-%H%M%S', time.localtime()), test_method_name))
        else:
            write_log('No exception in %s method.' % test_method_name)

    def qtest_reset_add(self):
        # 添加集中器编号为name
        self.reset_add_concentrator()
        self.check_reset()

    def test_reset_modify(self):
        # 添加集中器编号为name
        self.delete_by_code_name("zongff-1234")
        self.add_concentrator("zongff-1234")
        self.reset_modify_concentrator("zongff-1234")
        self.check_reset_modify("zongff-1234")
        self.delete_by_code_name("zongff-1234")

if __name__ == '__main__':
    unittest.main()
