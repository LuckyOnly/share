# coding=utf-8

import time
import sys
import unittest
from Function.Logging import write_log
from Page_Object.base_information.concentrator_model import ConcentratorModel
from Function import unit

directory = sys.path[1]


class ConcentratorQuery(unit.unit, ConcentratorModel):
    def setUp(self):
        self.click_page1("基础信息", "集中器型号")

    def tearDown(self):
        test_method_name = self._testMethodName
        if sys.exc_info()[0]:
            self.driver.save_screenshot(r"%s\ScreenShots\%s_%s.png" % (
                directory, time.strftime(r'%Y-%m-%d-%H%M%S', time.localtime()), test_method_name))
        else:
            write_log('No exception in %s method.' % test_method_name)

    def qtest08_modify_type_concentration(self):
        # 修改设备厂家
        modify_name = '型号编码'
        name_a = 'zongff-1234'
        name_b = 'zongff-4321'
        self.add_concentrator(name_a)
        self.modify_code_name(modify_name, name_a, name_b)
        self.check_result_by_name(name_b)
        self.delete_by_code_name(name_b)
        # self.check_result_by_delete_name(name_b)

    def test09_delete_type_concentration(self):
        # 删除集中器
        delete_name = 'zongff-4321'
        self.add_concentrator(delete_name)
        time.sleep(3)
        self.delete_by_code_name(delete_name)
        self.check_result_by_delete_name(delete_name)


if __name__ == '__main__':
    unittest.main()

