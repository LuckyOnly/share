# coding=utf-8

import time
import sys
import unittest
from Page_Object.base_information.equipment_manufacturers import EquipmentManufacturers
from Function import unit
from Function.Logging import write_log
directory =sys.path[1]


class ManufacturersQuery(unit.unit, EquipmentManufacturers):

    def setUp(self):
        self.click_page1("基础信息", "设备厂家")

    def tearDown(self):
        test_method_name = self._testMethodName
        if sys.exc_info()[0]:
            self.driver.save_screenshot(r"%s\ScreenShots\%s_%s.png" % (
                directory, time.strftime(r'%Y-%m-%d-%H%M%S', time.localtime()), test_method_name))
        else:
            write_log('No exception in %s method.' % test_method_name)

    def test_reset_query(self):
        self.reset_query()
        self.check_reset_result()

if __name__ == '__main__':
    unittest.main()

