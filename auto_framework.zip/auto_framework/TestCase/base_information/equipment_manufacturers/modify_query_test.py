# coding=utf-8

import time
import sys
import unittest
from Page_Object.base_information.equipment_manufacturers import EquipmentManufacturers
from Function import unit
from Function.Logging import write_log

directory = sys.path[1]


class ManufacturersQuery(unit.unit, EquipmentManufacturers):
    def setUp(self):
        self.click_page1("基础信息", "设备厂家")
        self.add_query()

    def tearDown(self):
        self.delete_name(100)
        test_method_name = self._testMethodName
        if sys.exc_info()[0]:
            self.driver.save_screenshot(r"%s\ScreenShots\%s_%s.png" % (
                directory, time.strftime(r'%Y-%m-%d-%H%M%S', time.localtime()), test_method_name))
        else:
            write_log('No exception in %s method.' % test_method_name)

    def test01_modify_query(self):
        name="联系电话"
        name_a='zong-f-f'
        name_b='12345678999'
        self.modify_query(name, name_a, name_b)
        self.cond_query_by_name(name_a)
        self.check_result_by_name(name, name_a, name_b)

    def test02_modify_query(self):
        name="联系人"
        name_a='zong-f-f'
        name_b='ffzong'
        self.modify_query(name, name_a, name_b)
        self.cond_query_by_name(name_a)
        self.check_result_by_name(name, name_a, name_b)

    def test03_modify_query(self):
        name="厂家地址"
        name_a='zong-f-f'
        name_b='test'
        self.modify_query(name, name_a, name_b)
        self.cond_query_by_name(name_a)
        self.check_result_by_name(name, name_a, name_b)


if __name__ == '__main__':
    unittest.main()

