# coding:utf-8

import time
import sys
import unittest
from Page_Object.base_information.equipment_model import EquipmentModel
from Function import unit
from Function.Logging import write_log
directory = sys.path[1]
name = 'zong-f-f'

class ManufacturersModelQuery(unit.unit, EquipmentModel):
    def setUp(self):
        self.click_page1("基础信息", "设备型号")
        self.cond_add(name)

    def tearDown(self):
        test_method_name = self._testMethodName
        if sys.exc_info()[0]:
            self.driver.save_screenshot(r"%s\ScreenShots\%s_%s.png" % (
                directory, time.strftime(r'%Y-%m-%d-%H%M%S', time.localtime()), test_method_name))
        else:
            write_log('No exception in %s method.' % test_method_name)

    def qtest09_concentrator_modify(self):
        modify_name = "型号编码"
        name_a = "zong-f-f"
        name_b = "zong-f-f-1"
        # self.delete_by_name("zong-f-f")
        self.cond_add(name_a)
        self.cond_modify_by_name(modify_name, name_a, name_b)
        self.check_modify(modify_name, name_b, name_b)
        self.delete_by_name(name_b)

    def test10_concentrator_delete(self):
        self.delete_by_name(name)
        self.check_by_name(name)

if __name__ == '__main__':
    unittest.main()