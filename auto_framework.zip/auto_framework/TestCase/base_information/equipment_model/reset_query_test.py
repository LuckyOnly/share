# coding: utf-8

import time
import sys
import unittest
from Page_Object.base_information.equipment_model import EquipmentModel
from Function import unit
from Function.Logging import write_log
directory = sys.path[1]

name_a = "zong-f-f"
class ManufacturersModelQuery(unit.unit, EquipmentModel):

    def setUp(self):
        self.click_page1("基础信息", "设备型号")
        self.delete_by_name(name_a)
        self.cond_add(name_a)

    def tearDown(self):
        self.delete_by_name(name_a)
        test_method_name = self._testMethodName
        if sys.exc_info()[0]:
            self.driver.save_screenshot(r"%s\ScreenShots\%s_%s.png" % (
                directory, time.strftime(r'%Y-%m-%d-%H%M%S', time.localtime()), test_method_name))
        else:
            write_log('No exception in %s method.' % test_method_name)



    def test_concentrator_reset_by_name(self):
        modify_name="电表类型"
        name_b="一次表"
        name_b_original ="二次表"
        self.cond_reset_by_name(modify_name,name_a,name_b)
        self.check_modify(modify_name, name_a, name_b_original)


if __name__ == '__main__':
    unittest.main()

