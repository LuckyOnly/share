# coding: utf-8

import time
import sys
import unittest
from Page_Object.base_information.equipment_model import EquipmentModel
from Function import unit
from Function.Logging import write_log
directory = sys.path[1]


class ManufacturersModelQuery(unit.unit, EquipmentModel):

    def setUp(self):
        self.click_page1("基础信息", "设备型号")

    def tearDown(self):
        test_method_name = self._testMethodName
        if sys.exc_info()[0]:
            self.driver.save_screenshot(r"%s\ScreenShots\%s_%s.png" % (
                directory, time.strftime(r'%Y-%m-%d-%H%M%S', time.localtime()), test_method_name))
        else:
            write_log('No exception in %s method.' % test_method_name)

    def test_concentrator_query(self):
        self.cond_query()
        self.check_result()

    def test_concentrator_query_by_name(self):
        self.check_result_by_name('NTS-220GS-2-1')

    def qtest_concentrator_reset(self):
        self.cond_reset("zongff")
        self.check_reset()

if __name__ == '__main__':
    unittest.main()

