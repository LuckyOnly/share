# coding: utf-8

import time
import sys
import os
import unittest
from Page_Object.base_information.upload_group_file import UploadFile
from Function import unit
from Function.Logging import write_log
directory = sys.path[1]
os.chdir(directory)
name = directory + r'\TestCase\base_information\upload_group_file\file\2018.xlsx'


class UploadFile(unit.unit, UploadFile):

    def setUp(self):
        self.click_page1("基础信息", "广场接入文件列表")

    def tearDown(self):
        test_method_name = self._testMethodName
        if sys.exc_info()[0]:
            self.driver.save_screenshot(r"%s\ScreenShots\%s_%s.png" % (
                directory, time.strftime(r'%Y-%m-%d-%H%M%S', time.localtime()), test_method_name))
        else:
            write_log('No exception in %s method.' % test_method_name)

    def test_query(self):
        # name = os.getcwd() + r'\file\2018.xlsx'
        # name = sys.path[0]+ r'\file\2018.xlsx'
        self.add_file_by_name(name)
        self.cond_query()
        self.check_result_by_group("长沙开福万达广场")

if __name__ == "__main__":
    unittest.main()