#coding=utf-8

import time
import sys
import pymysql
import unittest
sys.path.append("D:\\auto_framework\\")
from Page_Object.base_information.tariff_management import tariff_management
from selenium import webdriver
from selenium.webdriver.support.wait import WebDriverWait
from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC
from Function import unit
from Function.Logging import log


'''
# 类执行前被执行
def setUpModule():
    global conn, cu
    conn=pymysql.connect(host='127.0.0.1',user='root',password='123456',port=3306,database='test',charset='utf8')
    cu=conn.cursor()
    print ("connect database ")

def tearDownModule():
    cu.close()
    conn.close()
    print ("exit databse ")
'''

class tariffmanagement_query(unit.unit,tariff_management): #多继承，直接使用user_management和Page_Base类中所有方法

    def setUp(self):
        print ("1")
        #self.driver.refresh()
        self.click_page1("基础信息","费率管理")
        # above = self.driver.find_element_by_link_text("报表查询")
        # ActionChains(self.driver).move_to_element(above).perform()
        # time.sleep(5)
        # #lefts = WebDriverWait(self.driver, 20, 0.5).until(ec.presence_of_element_located((By.LINK_TEXT, '集中器型号')))
        # lefts = self.driver.find_element_by_link_text("广场报表")
        #
        # time.sleep(2)
        # lefts.click()


    def tearDown(self):
        print ("2")
        if sys.exc_info()[0]:
            test_method_name = self._testMethodName
            self.driver.save_screenshot("D:\\auto_framework\\ScreenShots\\%s_%s.png" % (test_method_name,time.strftime(r'%Y-%m-%d-%H%M%S', time.localtime())))

    @log
    def test_tariffmanagement_query(self):
        #self.click_page("系统基础管理", "用户管理")

        print ("3")
        time.sleep(1)
        self.cond_query()
        self.check_result()
        # self.driver.find_element_by_id("sltStationType").find_elements_by_tag_name("option")[2].click()
        # self.driver.find_element_by_id("sltFactorys").find_elements_by_tag_name("option")[1].click()
        # passdriver = WebDriverWait(self.driver, timeout=10).until(ec.presence_of_element_located((By.ID, 'Address')),
        #                                                      message=u"元素加载超时！")
        # passdriver.send_keys("NTS-165")


        # check = WebDriverWait(self.driver, timeout=20).until(
        #     ec.presence_of_element_located((By.XPATH, "//*[@id='dataList']/tr/td")), message=u"元素加载超时！")


        # try:
        #     #self.assertEqual(self.driver.find_element_by_xpath("//*[@id='dataList']/tr/td").text,u"暂无数据信息",msg="查询失败，无满足条件的记录")
        #     Result = self.driver.find_element_by_xpath("//*[@id='dataList']/tr/td").text
        #     self.assertNotEquals(Result, "暂无数据信息", msg="MSG查询无数据")
        #     print("Result=%s" %Result)
        #     if (u"暂无数据信息" == Result):
        #         print ("查询失败，无满足条件的记录")
        #     else:
        #         print ("查询成功，有满足条件的记录")
        #
        # except:
        #     print ("查询异常")



        # self.find_element((By.ID, 'accountName')).send_keys('dzy')
        # self.click_button('查询')
        # time.sleep(2)
        # cu.execute("update test_data set http_method='POST' where case_id=1")
        # conn.commit()

    # @log
    # def test_002(self):
    #     print ("4")
    #     #self.click_button('恢复默认')
    #     self.find_element((By.ID,'accountName')).send_keys('tessss')
    #     self.click_button('查询')
    #     time.sleep(2)
'''

    def test_login2(self):
        login(self.driver).user_login(username='user_no_exist', password='adminadmin')
        self.assertEqual(login(self.driver).login_error_hint(),u'输入的用户名user_no_exist不存在,请重新输入')
        print ("login error")
'''
if __name__=='__main__':
    unittest.main()

