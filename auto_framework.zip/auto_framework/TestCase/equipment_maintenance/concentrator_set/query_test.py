# coding=utf-8

import time
import sys
import unittest
from Page_Object.equipment_maintenance.concentrator_set import concentrator_set
from Function import unit
from Function.Logging import write_log
directory = sys.path[1]



class concentratorset_query(unit.unit,concentrator_set):
    # 进入二级目录
    def setUp(self):
        self.click_page1("设备维护","集中器设置")


    #关闭浏览器
    def tearDown(self):
        test_method_name = self._testMethodName
        if sys.exc_info()[0]:
            self.driver.save_screenshot(r"%s\ScreenShots\%s_%s.png" % (
                directory, time.strftime(r'%Y-%m-%d-%H%M%S', time.localtime()), test_method_name))
        else:
            write_log('No exception in %s method.' % test_method_name)
    # 删除电表档案
    # def test_device_delete(self):
        # self.dele_equip('WS0116');
        # self.dele_result('WS0116');

        # 添加电表，需要填写电表的设备编号
    # def test_001(self):
    #     time.sleep(3)
        # self.cond_query1()
        # self.add_equip('WS0118')


    # 一键查询查询电表
    # def test_002(self):
    #     time.sleep(3)
        # self.cond_query1()
        # self.check_result1()

    def test_03(self):
        time.sleep(3)
        self.cond_query("广场名称", "长沙开福万达广场")
        self.check_result()

    def test_04(self):
        time.sleep(3)
        self.cond_query("集中器类型", "商业")
        self.check_result()

    def test_05(self):
        time.sleep(3)
        self.cond_query("通讯状态", "异常")
        self.check_result()

    def test_06(self):
        time.sleep(3)
        self.cond_query("设备厂家", "南京天溯")
        self.check_result()

    def test_07(self):
        time.sleep(3)
        self.cond_query("型号", "NTS-165")
        self.check_result()

    def test_08(self):
        time.sleep(3)
        self.cond_query("集中器地址", "1")
        self.check_result()

if __name__ == '__main__':
    unittest.main()

