# coding=utf-8

import time
import sys
import unittest
from Function.Logging import write_log
from Page_Object.equipment_maintenance.device_management import DeviceManagement
from Function import unit
directory = sys.path[1]
name = "240ZF170815013"


class ConcentratorQuery(unit.unit, DeviceManagement):
    def setUp(self):
        self.click_page1("设备维护", "设备管理")


    def tearDown(self):
        test_method_name = self._testMethodName
        if sys.exc_info()[0]:
            self.driver.save_screenshot(r"%s\ScreenShots\%s_%s.png" % (
                directory, time.strftime(r'%Y-%m-%d-%H%M%S', time.localtime()), test_method_name))
        else:
            write_log('No exception in %s method.' % test_method_name)

    def test01_delete(self):
        # 删除电表
        self.delete_name(name)

if __name__ == '__main__':
    unittest.main()

