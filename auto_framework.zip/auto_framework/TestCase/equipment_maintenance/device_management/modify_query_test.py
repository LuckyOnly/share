# coding=utf-8

import time
import sys
import unittest
from Function.Logging import write_log
from Page_Object.equipment_maintenance.device_management import DeviceManagement
from Function import unit
directory = sys.path[1]
name = "240ZF170815013"


class ConcentratorQuery(unit.unit, DeviceManagement):
    def setUp(self):
        self.click_page1("设备维护", "设备管理")
        self.delete_name(name)
        self.add_device(name)

    def tearDown(self):
        self.delete_name(name)
        test_method_name = self._testMethodName
        if sys.exc_info()[0]:
            self.driver.save_screenshot(r"%s\ScreenShots\%s_%s.png" % (
                directory, time.strftime(r'%Y-%m-%d-%H%M%S', time.localtime()), test_method_name))
        else:
            write_log('No exception in %s method.' % test_method_name)

    def test01_modify(self):
        # 添加电表
        chose_name = "型号"
        type_name = "NTS-240GS-3-2"
        self.modify_device(chose_name, name, type_name)
        self.cond_by_name(name)
        self.check_modify(chose_name, name, type_name)

    def test02_modify(self):
        # 添加电表
        chose_name = "通道号"
        type_name = "3"
        self.modify_device(chose_name, name, type_name)
        self.cond_by_name(name)
        self.check_modify(chose_name, name, type_name)

    def test03_modify(self):
        # 添加电表
        chose_name = "楼层"
        type_name = "3"
        self.modify_device(chose_name, name, type_name)
        self.cond_by_name(name)
        self.check_modify(chose_name, name, type_name)

    def test04_modify(self):
        # 添加电表
        chose_name = "井号"
        type_name = "3"
        self.modify_device(chose_name, name, type_name)
        self.cond_by_name(name)
        self.check_modify(chose_name, name, type_name)
    def test05_modify(self):
        # 添加电表
        chose_name = "箱号"
        type_name = "3"
        self.modify_device(chose_name, name, type_name)
        self.cond_by_name(name)
        self.check_modify(chose_name, name, type_name)

    def test06_modify(self):
        # 添加电表
        chose_name = "变比"
        type_name = "3"
        self.modify_device(chose_name, name, type_name)
        self.cond_by_name(name)
        self.check_modify(chose_name, name, type_name)

    def test07_modify(self):
        # 添加电表
        chose_name = "通道地址"
        type_name = "240ZF170815113"
        self.modify_device(chose_name, name, type_name)
        self.cond_by_name(name)
        self.check_modify(chose_name, name, type_name)

    def test08_modify(self):
        # 添加电表
        chose_name = "设备名称"
        type_name = "WS3333"
        self.modify_device(chose_name, name, type_name)
        self.cond_by_name(name)
        self.check_modify(chose_name, name, type_name)

if __name__ == '__main__':
    unittest.main()

