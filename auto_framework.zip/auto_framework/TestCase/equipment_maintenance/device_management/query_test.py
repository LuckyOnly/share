# coding=utf-8

import time
import sys
import unittest
from Page_Object.equipment_maintenance.device_management import DeviceManagement
from Function import unit
from Function.Logging import write_log
directory = sys.path[1]
name = "240ZF170815013"


class DeviceManagementQuery(unit.unit, DeviceManagement):

    def setUp(self):
        self.click_page1("设备维护", "设备管理")
        self.add_device(name)

    def tearDown(self):
        self.delete_name(name)
        test_method_name = self._testMethodName
        if sys.exc_info()[0]:
            self.driver.save_screenshot(r"%s\ScreenShots\%s_%s.png" % (
                directory, time.strftime(r'%Y-%m-%d-%H%M%S', time.localtime()), test_method_name))
        else:
            write_log('No exception in %s method.' % test_method_name)

    def test_device_query_01(self):
        self.cond_query_by_name("设备厂商")
        self.check_cond_result_by_name("设备厂商")

    def test_device_query_02(self):
        self.cond_query_by_name("电表编号")
        self.check_cond_result_by_name("电表编号")

    def test_device_query_03(self):
        self.cond_query_by_name("电表名称")
        self.check_cond_result_by_name("电表名称")

if __name__ == '__main__':
    unittest.main()

