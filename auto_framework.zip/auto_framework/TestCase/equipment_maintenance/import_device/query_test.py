# coding=utf-8

import time
import sys
import unittest
from Page_Object.equipment_maintenance.import_device import ImportDevice
from Function import unit
from Function.Logging import write_log
directory = sys.path[1]


class DeviceQuery(unit.unit, ImportDevice): #多继承，直接使用user_management和Page_Base类中所有方法

    def setUp(self):
        print ("电表导入")
        self.driver.refresh()
        self.click_page1("设备维护", "电表导入")

    def tearDown(self):
        test_method_name = self._testMethodName
        if sys.exc_info()[0]:
            self.driver.save_screenshot(r"%s\ScreenShots\%s_%s.png" % (
                directory, time.strftime(r'%Y-%m-%d-%H%M%S', time.localtime()), test_method_name))
        else:
            write_log('No exception in %s method.' % test_method_name)

    def test_001_device_query(self):
        print ("上传电表")
        time.sleep(3)
        self.cond_query()
        time.sleep(3)
        self.check_result()


if __name__ == '__main__':
    unittest.main()

