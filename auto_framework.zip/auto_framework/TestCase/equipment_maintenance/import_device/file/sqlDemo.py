#coding:utf-8
import pymssql
class MSSQL:
    def __init__(self,host,user,password,database):
        self.host=host
        self.user=user
        self.password=password
        self.database=database
    def __GetConn(self):
        if not self.database:
            raise (NameError,"no database")
        self.conn = pymssql.connect(host=self.host, user=self.user, password=self.password, database=self.database)
        '''
               conn=pymssql.connect(host='.',database='XXX')
         '''
        cur = self.conn.cursor()
        if not cur:
            raise (NameError,"fail to connect the database")
        else:
            return cur
    def ExecQuery1(self,sql,id):
        cur = self.__GetConn()
        cur=self.__GetConn()
        cur.execute(sql,id)
        resList=cur.fetchall()
        self.conn.close()
        return resList
    def ExcuNotQuery1(self,sql,id):
        cur = self.__GetConn()
        cur.execute(sql,id)
        self.conn.commit()
        self.conn.close()
    def sizeList(self,list):
        return len(list)
    def ExecQuery(self,sql):
        cur=self.__GetConn()
        cur.execute(sql)
        resList=cur.fetchall()
        self.conn.close()
        return resList
    def ExcuNotQuery(self,sql):
        cur = self.__GetConn()
        cur.execute(sql)
        self.conn.commit()
        self.conn.close()
    def closeSql(self):
        self.cur.close()
        self.conn.close()
    def solve(self,sql1,sql2,id):
        result=self.ExecQuery1(sql1,id)
        l=len(result)
        if l>0:
            self.ExcuNotQuery1(sql2,id)
            return u'the data delete success'
        else:
            return u'no data,no clear'
def main(id):
        ms=MSSQL(host='192.168.50.80\\sql2012',user='sa',password='iamnts',database='NTS-9000_WandaBase')
        print u'TB_DEVICE:'+ms.solve('SELECT * from TB_DEVICE where  id= %s','delete from TB_DEVICE where id=%s',id)
        print u'tb_payment_room:'+ms.solve('SELECT * from tb_payment_room where id= %d','delete from tb_payment_room where id=%d',id)
        print u'TB_DEVICE_PROPERTY:'+ms.solve('SELECT * from TB_DEVICE_PROPERTY where id= %d','delete from TB_DEVICE_PROPERTY where id=%d',id)
        print u'TB_PAYMENT_DEVICE_EX:'+ms.solve('SELECT * from TB_PAYMENT_DEVICE_EX where DEVICEID= %s','delete from TB_PAYMENT_DEVICE_EX where DEVICEID= %s',id)
        print u'TB_DI:'+ms.solve('SELECT * from TB_DI where DEVICENUM= %s','delete from TB_DI where DEVICENUM= %s',id)
        print u'TB_PULSE:'+ ms.solve('SELECT * from TB_PULSE where DEVICENUM= %s','delete from TB_PULSE where DEVICENUM= %s',id)
        print u'tb_payment_room:'+ms.solve('SELECT * from tb_payment_room where id= %d','delete from tb_payment_room where id= %d',id+10000000)
        print u'tb_payment_virtual_device:'+ms.solve('SELECT * from tb_payment_virtual_device where conid= %s','delete from tb_payment_virtual_device where conid= %s',id)
        print u'tb_samplehour_ext:'+ms.solve('SELECT * from tb_samplehour_ext WHERE deviceid = %s','delete from tb_samplehour_ext WHERE deviceid = %s',id)
        print u'tb_samplehour_ext:'+ms.solve('SELECT * from tb_sampleday_ext WHERE deviceid = %s','delete from tb_sampleday_ext WHERE deviceid = %s',id)
        print u'tb_control:'+ms.solve('SELECT * from tb_control where  id= %d','delete from tb_control where  id= %d',id*100+1)

if __name__ == '__main__':
    main(2009)