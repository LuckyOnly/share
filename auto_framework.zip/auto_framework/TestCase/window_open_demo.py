# coding:utf-8
from Function import unit
import unittest

class window_demo(unit.unit):
    def setUp(self):
        pass

    def test_01(self):
        js ='window.open("http://192.168.50.80:7800/brand_management.html")'
        self.driver.execute_script(js)

    def tearDown(self):
        pass


if __name__ == '__main__':
    unittest.main()