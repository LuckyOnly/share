#-*- coding: UTF-8 -*-'
from time import sleep
import time
import sys
sys.path.append("D:\\auto_framework\\")
from Function.unit import unit
from Function.Logging import log
from Page_Object.system_config_management.device_point import device_point
import unittest

class TestDevicePoint(unit, device_point):
    def setUp(self):
        # 点击到个人信息界面
        self.driver.refresh()
        self.get_element("title", 5).click()  # 点击系统基础管理
        sleep(1)
        self.get_element("title2", [5, 1]).click()  # 点击设备点位
        sleep(5)  # 等待加载
        return

    def tearDown(self):
        print '1'
        if sys.exc_info()[0]:
            sleep(2)
            print sys.exc_info()[0]
            test_method_name = self._testMethodName
            self.driver.save_screenshot("C:\\Users\\lenovo\\Desktop\\py\\eway\\ScreenShots\\%s_%s.png" % (test_method_name,time.strftime(r'%Y-%m-%d-%H%M%S', time.localtime())))
            sleep(2)
        #self.driver.refresh()
        sleep(5)
        return

    # @log
    # def test1_AddVirtual(self):
    #     # 测试新增
    #     self.get_element("link", u"新增").click()  # 点击新增
    #     sleep(2)
    #     self.driver.switch_to.frame(self.get_element("frame"))
    #     self.AddVirtual(["test_zhr", [2, 1, 1, 3], [3, 2, 1], [4, 3, 1], [3], 2, "test_zhr", u"一些描述", "A001", 1, 1])
    #     self.driver.switch_to.default_content()
    #     sleep(3)
    #     print(u"新增虚拟点位成功")

    @log
    def test2_AddPhysical(self):
        #self.driver.execute_script("window.scrollTo(0,0);")  # 滑到顶部
        self.get_element("link", u"新增").click()  # 点击新增
        sleep(2)
        self.driver.switch_to.frame(self.get_element("frame"))
        self.AddPhysical(["test_zhr2", [2, 1, 1, 3], [3, 2, 1], [4, 3, 1], [3], 2, "test_zhr2", u"一些描述", 1])
        self.driver.switch_to.default_content()
        sleep(3)
        print(u"新增物理点位成功")

    # @log
    # def test3_Search(self):
    #     # 测试搜索
    #     today = time.strftime("%Y-%m-%d", time.localtime(time.time()))
    #     self.Search(["test", 1, today, ""])
    #     count = len(self.get_element('table_rows'))
    #     #self.assertGreaterEqual(count, 2)
    #     print(u"搜索功能测试通过")
    #
    # @log
    # def test4_Edit(self):
    #     # 测试编辑功能
    #     self.get_element("link_in_table", [1, 7, 2]).click()  # 点击编辑
    #     sleep(4)
    #     self.driver.switch_to.frame(self.get_element("frame"))
    #     self.Edit([1])
    #     self.driver.switch_to.default_content()
    #     sleep(2)
    #     print(u"编辑功能测试通过")
    #
    # @log
    # def test5_Able(self):
    #     # 测试启用禁用
    #     self.Enable([3, 5, 6])
    #     sleep(1)
    #     print(u"批量启用测试通过")
    #     self.Disable([3, 5, 6])
    #     sleep(1)
    #     print(u"批量禁用测试通过")

    # @log
    # def test6_Load(self):
    #     # 测试导入和下载
    #     self.Load()
    #     sleep(3)
    #     print(u"批量上传测试通过")
    #
    #     self.execSql("delete from tb_sensors where sensor_name like 'test_zhr%'")  # python指令似乎不支持utf-8，所以用英文名
    #     #self.execSql2("delete from tb_sensors where sensor_name like 'test_zhr%'")
    #     return

if __name__=='__main__':
    unittest.main()
