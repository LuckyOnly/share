# coding: utf-8

import time
import sys
import unittest
from Page_Object.rights_management.user_management import user_management
from Function import unit
from Function.Logging import write_log
directory = sys.path[1]


class UserManagementQuery(unit.unit, user_management):

    def setUp(self):
        self.click_page1("权限管理", "用户管理")

    def tearDown(self):
        test_method_name = self._testMethodName
        if sys.exc_info()[0]:
            self.driver.save_screenshot(r"%s\ScreenShots\%s_%s.png" % (
                directory, time.strftime(r'%Y-%m-%d-%H%M%S', time.localtime()), test_method_name))
        else:
            write_log('No exception in %s method.' % test_method_name)

    def test_usermanagement_query(self):
        time.sleep(1)
        self.cond_query()
        self.check_result()

if __name__ == '__main__':
    unittest.main()

