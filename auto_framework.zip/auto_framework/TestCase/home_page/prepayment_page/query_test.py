# coding:utf-8
from Page_Object.home_page.prepayment_page import PrePayment
from Function import unit
import unittest
import sys
import time
import traceback
from Function.Logging import write_log
directory = sys.path[1]
sys.path.append("Z:\\project\\auto_framework\\Page_Object")


class TodoPage(unit.unit, PrePayment):

    def setUp(self):
        self.click_page2("首页")

    def test_prepayment(self):
        self.cond_query()
        self.check_query()

    def tearDown(self):
        test_method_name = self._testMethodName
        if sys.exc_info()[0]:
            self.driver.save_screenshot(r"%s\ScreenShots\%s_%s.png" % (
                directory, time.strftime(r'%Y-%m-%d-%H%M%S', time.localtime()), test_method_name))
            log = 'Exception in ' + test_method_name + ' method: ' + traceback.format_exc()
            write_log(log)
        else:
            write_log('No exception in %s method.' % test_method_name)

if __name__ == '__main__':
    unittest.main()