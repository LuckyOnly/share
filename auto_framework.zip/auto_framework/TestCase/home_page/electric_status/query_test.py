# coding:utf-8

from Page_Object.home_page.electric_status import ElectricStatus
from Function import unit
import sys
import time
import unittest
import traceback
from Function.Logging import write_log
directory=sys.path[1]
sys.path.append('Z:\\project\\auto_framework\\Page_Object')


class StatisticsDemo(unit.unit,ElectricStatus):

    def setUp(self):
        self.click_page2('首页')

    def test_square_count(self):
        """接入广场数量"""
        self.check_query('labSquareCount')

    def test_merchant_count(self):
        """接入电表数量"""
        self.check_query('labMerchantCount')

    def test_preMeter_count(self):
        """品牌电表数量"""
        self.check_query('labPreMeterCount')

    def test_three_day_meter_count(self):
        """仅可用3天电表数量"""
        self.check_query('labThreeDayMeterCount')

    def test_after_meter_count(self):
        """电表数量"""
        self.check_query('labAftMeterCount')

    def test_last_month_red_light_count(self):
        """上月红灯数量"""
        self.check_query('labLastMonthRedLightCount')

    def test_prepaid(self):
        """品牌电表总金额"""
        self.check_query('labPrepaid')

    def test_arrears_fee(self):
        """品牌电表欠费总金额"""
        self.check_query('labArrearsFee')

    def test_aft_arrears_fee(self):
        """后付费应缴总额"""
        self.check_query('labAftArrearsFee')

    def test_red_light_count(self):
        """当前红灯数量"""
        self.check_query('labRedLightCount')

    def test_pre_merchant_count(self):
        """预付费总品牌数"""
        self.check_query('labPreMerchantCount')

    def test_arrears_meter_count(self):
        """已欠费电表数量"""
        self.check_query('labArrearsMeterCount')

    def test_aft_merchant_count(self):
        """后付费总品牌数"""
        self.check_query('labAftMerchantCount')

    def test_last_yellow_light_count(self):
        """当前黄灯数量"""
        self.check_query('labLastYellowLightCount')

    def tearDown(self):
        test_method_name = self._testMethodName
        if sys.exc_info()[0]:
            self.driver.save_screenshot(r"%s\ScreenShots\%s_%s.png" % (
                directory, time.strftime(r'%Y-%m-%d-%H%M%S', time.localtime()), test_method_name))
        else:
            write_log('No exception in %s method.' % test_method_name)

if __name__ == '__main__':
    unittest.main()