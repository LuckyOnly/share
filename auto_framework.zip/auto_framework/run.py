# coding:utf-8
import unittest
import time
from HTMLTestRunner import HTMLTestRunner

import sys

reload(sys)
sys.setdefaultencoding('utf8')

if __name__ == '__main__':
    test_dir = './TestCase/home_page/'
    DATE = time.strftime(r'%Y-%m-%d-%H%M%S', time.localtime())
    fp = open('./report/' + 'wanda_test_' + DATE + '.html', 'wb')
    runner = HTMLTestRunner(stream=fp, title='万达计费自动化测试报告', description='用例执行情况--统计by YBC')
    discover = unittest.defaultTestLoader.discover(test_dir, pattern='*uery_test.py')
    runner.run(discover)
    fp.close()
